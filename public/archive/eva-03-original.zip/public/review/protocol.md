# EVA 03 — bounded design review

## Goal
Create an image-led EVA experience in which preventive health feels like an exciting part of life. Use the SAVEE board's optical defocus, grain and amber/lilac light on human subjects, factual Tasso+ reference imagery, and real reversible scroll-driven transitions authored with Remotion. Preserve core EVA information and every earlier design iteration.

## Stop rule
One full draft, a review of actual rendered scenes, then at most two focused correction passes. Finish only when the gates below pass. A successful build alone cannot pass the visual gates. Record limitations honestly; subjective approval remains with the user.

## Gates
1. **Connected scenes:** inspect frames 0, 171, 225, 325, 400, 480, 560, 680, 755 and 810. The same runner image expands; an aperture reveals the product; the product button expands into the information field; a horizontal opening reveals the final human artwork. Text fades alone cannot pass.
2. **Art direction:** compare the actual runner and stretch assets with SAVEE 08 and 09. Require observable optical defocus, grain, amber/blue/lilac light and a recognizable human subject. A conventional photograph with a CSS blur cannot pass.
3. **Actual scroll control:** on the experience page, native scroll changes the rendered Remotion frame. Return to an earlier chapter and verify its frame, pose, asset and geometry. Hold still for at least two seconds and verify no change. The final frame must remain 840 after leaving the pinned stage.
4. **Composed layouts:** review 1440×900 and 390×844. The portrait composition must reflow text and product sizing. No horizontal page overflow, covered headlines, illegible chapter controls, or broken product frames. Secondary results have an 80-frame stationary reading interval before the final wipe.
5. **EVA clarity and recovery:** ordinary HTML and reduced-motion mode retain Tasso+, 15 markers every quarter, optional 165+ panel, biological age/score, €99 per quarter, cancellation and free upload. Earlier sites and source archives remain linked. Real CTA destinations point to EVA.

## Improvements made after review
- Replaced conventional lifestyle imagery with two Higgsfield artworks generated with the actual SAVEE references.
- Replaced the previous independent loop with 60 product frames selected by the Remotion timeline.
- Fixed phone product/title overlap and the visible white image rectangle.
- Anchored the product zoom to the button rather than the image center.
- Extended the secondary results reading hold to frames 635–715.
- Delayed chapter chrome color change until the final mask reaches it.
- Fixed incomplete local extraction and verified all 60 product frames exist.

## Repeat the test
Use /system to seek exact frames, inspect landscape and portrait compositions, and compare source imagery. Use the landing page's chapter navigation and native scrolling to check the actual scroll driver. The footer's reduced-motion switch removes the pinned sequence. Run `npm run check:delivery` after the production build for asset, core-copy and export checks. Results are recorded in results.json; they are observations, not an automated taste score.
