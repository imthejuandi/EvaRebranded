import {Composition} from 'remotion';
import {EvaFilm,DURATION} from '../components/story/EvaFilm';
export const RemotionRoot=()=> <><Composition id="EvaLandscape" component={EvaFilm} durationInFrames={DURATION} fps={30} width={1440} height={900}/><Composition id="EvaPortrait" component={EvaFilm} durationInFrames={DURATION} fps={30} width={390} height={844}/></>;
