import {readFile,stat} from 'node:fs/promises';
import assert from 'node:assert/strict';
import path from 'node:path';
const root=process.cwd();const base=path.join(root,'dist/client');const records=[];
for(const route of ['index.html','system.html','history.html']){const html=await readFile(path.join(base,route),'utf8');assert(html.includes('EVA')||html.includes('eva'));assert(!html.includes('Internal Server Error'));records.push({check:`export ${route}`,pass:true});}
const home=await readFile(path.join(base,'index.html'),'utf8');for(const term of ['Tasso+','165','15 biomarcadores','99','trimestre','Cancela','Súbela gratis','edad biológica'])assert(home.includes(term),`Missing core content: ${term}`);records.push({check:'EVA core information in static HTML',pass:true});
for(let i=0;i<60;i++){const p=path.join(base,'art/product',`frame-${String(i).padStart(3,'0')}.jpg`);const bytes=await readFile(p);assert(bytes.length>1000&&bytes[0]===255&&bytes[1]===216,`Broken frame ${i}`);}
records.push({check:'60 nonempty JPEG product frames in export',pass:true});
for(const image of ['runner.jpg','runner-athletic.jpg','stretch.jpg','savee-06.jpg','savee-08.jpg','savee-09.jpg','tasso-plus-in-use.png'])assert((await stat(path.join(base,'art',image))).size>1000);
records.push({check:'Human, SAVEE and factual Tasso assets present',pass:true});
const history=await readFile(path.join(base,'history.html'),'utf8');for(const old of ['eva-system-02','eva-instrument-study','eva-instrument-landing'])assert(history.includes(old));records.push({check:'All previous previews linked',pass:true});
for(const report of ['protocol.md','results.json','provenance.json'])assert((await stat(path.join(base,'review',report))).size>100);
records.push({check:'Review and provenance shipped',pass:true});
const clip=await readFile(path.join(base,'art/runner-athletic-loop.mp4'));assert(clip.length>20000&&clip.subarray(0,32).toString().includes('ftyp'));assert((await stat(path.join(base,'archive/eva-03-original.zip'))).size>1000000);records.push({check:'Ambient runner video and accepted 03.0 source archive present',pass:true});
console.log(JSON.stringify({passed:records.length,records},null,2));
