# EVA — System 03.1: Glow Motion

An isolated private design assessment. The live EVA website and GitHub application were not changed.

## Development
Node 24; `npm install`, `npm run dev -- --port 3017`. `npm run build` exports static files with Vinext. `npm run check:delivery` checks the actual exported routes, core content and all 60 product images.

`npm run motion:studio` opens the registered Remotion landscape and portrait compositions. The site embeds the same EvaFilm component with a paused Remotion Player. Native scroll selects frames 0–840. The design lab exposes the same timeline with a slider.

## Reusable pieces
- `components/story/EvaFilm.tsx`: frame-authored scene transformations and product sequence.
- `components/story/ScrollStory.tsx`: native scroll controller, semantic narrative, chapter controls and reduced motion.
- `components/story/Editorial.tsx`: method, founder and factual Tasso+ image.
- `components/story/DesignLab.tsx`: frame inspector, art comparison and visual system.
- `lib/design.ts` and `app/globals.css`: design tokens and reusable page rules.
- `public/art`: artwork, SAVEE reference images and verified product frames.
- `public/review`: acceptance protocol, evidence and provenance.

## Sources
Sofi Health and Clearwater inform spatial transitions and editorial scale. Two real 21st.dev CLI retrievals supplied Zoom Parallax (efferd, 5967) and Horizontal Scroll Gallery (pulkitxm, 20139); their measured patterns were adapted into Remotion rather than installed as unrelated components.

Higgsfield generated the runner and stretch artwork with the actual SAVEE 06/08/09 images as references (4 credits estimated in total). The device sequence is extracted from the previous Higgsfield product turn based on official Tasso+ imagery. It is an artistic product study, not a device-use tutorial or a CAD model. Official product and in-use references: https://www.tassoinc.com/tasso-plus and https://www.tassoinc.com/.

## Recovery
Version 02 remains at https://eva-system-02.jdlagop.chatgpt.site/ with its source archives and all 27 SAVEE references. Version 01 remains at https://eva-instrument-study.jdlagop.chatgpt.site/ and https://eva-instrument-landing.jdlagop.chatgpt.site/. The /history route links each version. This project is a separate Sites project and Git repository.

## Refinement 03.1
The opening now uses an athletic runner and an independent ambient running loop. `GlowMotion` is the reusable source-led image/video component, with controls in `GlowMotionSpecimen` and its palette/mask in `glowMotionStyle`. Remotion continues to drive all spatial scene transitions. The timeline inspector uses the refined still for repeatable comparisons. `/review/glow-motion.md` documents reuse and behavior. The accepted 03.0 source is downloadable from `/archive/eva-03-original.zip`; its original artwork stays at `/art/runner.jpg`.
