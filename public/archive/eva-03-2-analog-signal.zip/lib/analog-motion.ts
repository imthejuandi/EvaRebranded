export const SIGNAL_DURATION=361;
export const signalStops=[0,160,340];
export const signalLabels=['15 biomarcadores','Cada 90 días','Tu vida, con contexto'];
const glyphs:Record<string,string[]>={
 '1':['00100','01100','00100','00100','00100','00100','01110'],
 '5':['11111','10000','10000','11110','00001','00001','11110'],
 '9':['01110','10001','10001','01111','00001','00001','01110'],
 '0':['01110','10001','10011','10101','11001','10001','01110'],
 'T':['11111','00100','00100','00100','00100','00100','00100'],
 'Ú':['10001','10001','10001','10001','10001','10001','01110'],
};
export const signalWords=['15','90','TÚ'];
export function pointsForWord(word:string){const points:{x:number;y:number}[]=[];[...word].forEach((letter,l)=>{glyphs[letter].forEach((row,y)=>[...row].forEach((value,x)=>{if(value==='1')points.push({x:x+l*6,y:y+1})}));if(letter==='Ú')points.push({x:l*6+3,y:-.4})});return points}
const forms=signalWords.map(pointsForWord);
const masks=forms.map(points=>new Set(points.map(p=>`${p.x},${p.y}`)));
const grid=[...Array.from({length:77},(_,i)=>({x:i%11,y:Math.floor(i/11)+1})),{x:9,y:-.4}];
const clamp=(n:number)=>Math.max(0,Math.min(1,n));
export function signalState(frame:number){
 const f=Math.max(0,Math.min(SIGNAL_DURATION-1,frame));
 const phase=f<160?clamp((f-55)/80):1+clamp((f-215)/80);
 const from=Math.min(1,Math.floor(phase)),to=Math.min(2,from+1),raw=phase-from;
 const step=Math.floor(raw*8)/8;
 const points=grid.map((p,i)=>{
  const useNext=step>=1||step>((i*7)%17)/16;
  const on=masks[useNext?to:from].has(`${p.x},${p.y}`);
  return {...p,r:on?.405:0};
 });
 return {phase,chapter:phase<.5?0:phase<1.5?1:2,points};
}
