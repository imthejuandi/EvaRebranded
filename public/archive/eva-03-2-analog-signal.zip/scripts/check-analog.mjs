import assert from 'node:assert/strict';
import {signalState,pointsForWord,signalStops,signalWords,SIGNAL_DURATION} from '../lib/analog-motion.ts';

const stable=signalStops.map(signalState);
for(let i=0;i<3;i++){
 const lit=stable[i].points.filter(p=>p.r>0).map(p=>`${p.x},${p.y}`).sort();
 const expected=pointsForWord(signalWords[i]).map(p=>`${p.x},${p.y}`).sort();
 assert.deepEqual(lit,expected,`Stable ${signalWords[i]} must be complete`);
}
const centerSignature=stable[0].points.map(p=>[p.x,p.y]);
const forward=[];
for(let f=0;f<SIGNAL_DURATION;f++){
 const state=signalState(f);assert(state.points.every(p=>Number.isFinite(p.x)&&Number.isFinite(p.y)&&[0,.405].includes(p.r)));
 assert.deepEqual(state.points.map(p=>[p.x,p.y]),centerSignature,'Dots must stay registered through every transition');
 forward.push(JSON.stringify(state));
}
for(let f=SIGNAL_DURATION-1;f>=0;f--)assert.equal(JSON.stringify(signalState(f)),forward[f],'Reverse navigation must return identical geometry');
assert.deepEqual(signalState(-50),signalState(0));assert.deepEqual(signalState(999),signalState(360));
assert.notDeepEqual(signalState(78).points,stable[0].points,'Scrolling into a transition must actually change the dot pattern');
console.log('Analog motion passed: complete 15/90/TÚ glyphs, fixed centers, all 361 frames finite, reversible and bounded, intermediate state changes.');
