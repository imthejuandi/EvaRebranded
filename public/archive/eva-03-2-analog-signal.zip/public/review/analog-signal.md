# Analog Signal

Two complementary treatments, saved as part of EVA 03.2.

## Character cells

`AnalogType` renders a serif silhouette sampled onto a square grid. Warm cream tiles carry small deterministic EVA / VIDA / SALUD characters. Keep the macro word readable; this treatment belongs in large display type, never body text, navigation or controls.

Props: `text`, `width`, `height`, optional `frame`, `color`, `style`. It works inside or outside Remotion. A native SVG text fallback is present before the canvas is ready. It is decorative; supply the meaningful text through a semantic heading nearby. The hero already has its accessible h1.

Use a frame supplied by the composition. There is no independent timer or random sequence. Microcharacters advance in nine-frame buckets; a restrained brightness sweep crosses the cells. Freeze the component after it leaves view. Canvas backing storage is resized only when dimensions change.

## Fixed dot display

`SignalFilm` is a 361-frame Remotion composition. The letters keep fixed positions, switching which dots are lit in eight discrete stages between stable forms. No circles travel. The three stable positions are 0 (15), 160 (90) and 340 (TÚ).

`SignalPassage` maps native scrolling through three viewport heights onto those frames. It has no autoplay. The visible chapter buttons are an alternative to scrolling. `AnalogSpecimen` exposes the same composition with a frame slider at `/system#analog-signal`.

The global reduced-motion setting replaces the pinned passage with a short, static text section. Initial/server rendering includes a readable fallback. The lettering and circles are hidden from assistive technology; headings and complete information are available as semantic text. Copy stays at least 37px above controls on the tested 320×568 viewport.

## Reference and adaptation

- User-supplied SAY LESS image: serif contours built from cream square tiles containing tiny letters. The supplied reference is retained in this private study at `/art/reference-analog-letters.png`.
- [SAVEE motion reference](https://savee.com/i/uBs8ZE0/), attributed to [Satto Studio](https://x.com/Satto_studio/status/2094148642168832020): black circular dots, fixed registration and fast stepped glyph swapping on white.
- EVA preserves that registered display language while letting the reader set its pace with scroll. The original video is linked as reference rather than included in the landing page.

## Acceptance gates

1. Hero word readable on desktop and phone; runner and soft glow remain visible.
2. Distinct 15, 90 and TÚ states with fixed dot centers.
3. Scroll changes the frame; an idle page holds it. The same frame always has identical dot geometry, in either direction.
4. Short-phone copy and controls do not overlap; no horizontal overflow.
5. Reduced motion shows complete static content. No autoplay added.
6. Both previous accepted 03.0 and 03.1 source archives remain recoverable.

Bounded loop: one implementation pass, one independent correctness review, corrections for concrete findings, then browser and build checks. Further revision only on a failed gate.
