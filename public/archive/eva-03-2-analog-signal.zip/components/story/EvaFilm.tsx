import {AbsoluteFill,Img,interpolate,useCurrentFrame,useVideoConfig} from 'remotion';
import {useEffect,useRef,useState} from 'react';
import {GlowMotion} from './GlowMotion';
import {glowRunner} from '@/lib/design';
import {AnalogType} from './AnalogType';
export const DURATION=841;
const clamp={extrapolateLeft:'clamp',extrapolateRight:'clamp'} as const;
const range=(f:number,a:number,b:number,x:number,y:number)=>interpolate(f,[a,b],[x,y],clamp);
export function EvaFilm({ambientRunner=true,onRunnerBlocked}:{ambientRunner?:boolean;onRunnerBlocked?:()=>void}={}){
 const f=useCurrentFrame();const {width:w,height:h}=useVideoConfig();const mobile=w<700;const pad=mobile?24:48;
 const zoom=range(f,45,180,1,mobile?2.6:4.8);const portal=range(f,190,280,0,Math.hypot(w,h)*.66);
 const productScale=range(f,425,530,1,6);const amber=range(f,465,555,0,Math.hypot(w,h));
 const exit=range(f,715,800,0,1);const scene=f<230?'Vivir':f<490?'Conocer':f<715?'Entender':'Seguir';
 const track=useRef<HTMLDivElement>(null);const [overflow,setOverflow]=useState(w);useEffect(()=>{const el=track.current;if(!el)return;const measure=()=>setOverflow(Math.max(0,el.scrollWidth-(w-pad*2)));measure();const ro=new ResizeObserver(measure);ro.observe(el);return()=>ro.disconnect()},[w,pad]);
 const pose=Math.round(range(f,285,430,0,59));
 return <AbsoluteFill data-rendered-frame={f} data-scene={scene} style={{background:'#0b1010',color:'#f3f0e8',fontFamily:'Arial, Helvetica, sans-serif',overflow:'hidden'}}>
  <AbsoluteFill data-layer="human" style={{opacity:f>285?0:1}}>
   {[{src:'savee-08.jpg',x:.10,y:.34,s:.16,m:7},{src:'savee-09.jpg',x:.82,y:.17,s:.13,m:8},{src:'savee-06.jpg',x:.87,y:.73,s:.15,m:6}].map((v,i)=><div key={v.src} style={{position:'absolute',left:w*v.x,top:h*v.y,width:w*v.s,height:h*.27,translate:'-50% -50%',scale:range(f,45,170,1,v.m),opacity:range(f,60,150,.5,0),rotate:`${i%2?8:-6}deg`}}><Img src={'/art/'+v.src} style={{width:'100%',height:'100%',objectFit:'cover',maskImage:'radial-gradient(ellipse,black 25%,transparent 72%)'}}/></div>)}
   <div data-layer="runner-plane" style={{position:'absolute',left:'50%',top:'50%',width:mobile?w*.72:w*.29,height:h*.83,translate:'-50% -50%',scale:zoom}}><GlowMotion {...glowRunner} inComposition enabled={ambientRunner} active={f<285} onPlaybackBlocked={onRunnerBlocked}/></div>
   <div style={{position:'absolute',left:pad,top:mobile?'19%':'20%',fontSize:mobile?w*.27:w*.2,lineHeight:.78,letterSpacing:'-.085em',fontWeight:500,translate:`${range(f,45,160,0,-w*.7)}px 0`}}>Más</div>
   <AnalogType text="vida." frame={Math.min(f,160)} width={mobile?w*.65:w*.43} height={mobile?w*.29:w*.21} style={{position:'absolute',right:pad,top:mobile?'59%':'48%',translate:`${range(f,45,160,0,w*.7)}px 0`}}/>
   <p style={{position:'absolute',left:pad,bottom:mobile?125:95,fontSize:mobile?16:18,lineHeight:1.45,maxWidth:260,opacity:range(f,20,90,1,0)}}>La salud preventiva.<br/>Una forma de vivir, a tu ritmo.</p>
   {!mobile&&<p style={{position:'absolute',right:pad,top:'23%',width:190,fontFamily:'Georgia,serif',fontSize:22,lineHeight:1.2,opacity:range(f,20,100,1,0)}}>Para todo lo que<br/>te queda por vivir.</p>}
  </AbsoluteFill>
  <AbsoluteFill data-layer="portal" style={{background:'#f3f0e8',color:'#171b18',clipPath:`circle(${portal}px at ${mobile?'50%':'58%'} 48%)`}}>
   <div data-layer="product" data-pose={pose} style={{position:'absolute',left:mobile?'50%':'58%',top:'48%',width:mobile?Math.min(w*.96,h*.48):Math.min(w*.53,h*.85),aspectRatio:'1',translate:'-47.5% -38.8%',transformOrigin:'47.5% 38.8%',scale:productScale,rotate:`${range(f,250,420,-12,5)}deg`,mixBlendMode:'multiply'}}><Img src={`/art/product/frame-${String(pose).padStart(3,'0')}.jpg`} style={{width:'100%',height:'100%',objectFit:'contain',filter:'brightness(1.04)'}}/></div>
   <div style={{position:'absolute',zIndex:1,top:mobile?'15%':'17%',left:pad,fontSize:mobile?Math.min(w*.11,48):w*.073,lineHeight:.94,letterSpacing:'-.06em',opacity:range(f,265,305,0,1)*(1-range(f,425,465,0,1)),translate:`0 ${range(f,265,320,60,0)}px`}}>Un pequeño<br/><span style={{fontFamily:'Georgia,serif',fontStyle:'italic',fontWeight:400}}>gesto.</span></div>
   <div style={{position:'absolute',right:pad,bottom:mobile?135:110,width:mobile?w-48:250,opacity:range(f,285,325,0,1)*(1-range(f,425,465,0,1))}}><p style={{fontSize:11,letterSpacing:'.13em',marginBottom:10}}>01 / TU MUESTRA, EN CASA</p><p style={{fontSize:mobile?18:22,lineHeight:1.3}}>Con Tasso+, conocer tu salud empieza con un gesto que cabe en tu día.</p></div>
  </AbsoluteFill>
  <AbsoluteFill data-layer="amber-aperture" style={{background:'#e9a067',color:'#22271f',clipPath:`circle(${amber}px at ${mobile?'50%':'58%'} 48%)`}}>
   <div style={{position:'absolute',top:mobile?'19%':'16%',left:pad,fontSize:mobile?51:w*.072,letterSpacing:'-.065em',lineHeight:.98}}>Conocerte<br/><span style={{fontFamily:'Georgia,serif',fontStyle:'italic'}}>cambia las cosas.</span></div>
   <div ref={track} data-layer="insight-track" data-overflow={overflow} style={{position:'absolute',left:pad,top:mobile?'46%':'47%',display:'flex',gap:pad,width:'max-content',translate:`${-range(f,590,635,0,overflow)}px 0`}}>
    <div style={{width:w-pad*2,display:'flex',alignItems:'center',gap:mobile?22:55}}><span style={{fontSize:mobile?Math.min(w*.37,155):w*.22,letterSpacing:'-.08em',lineHeight:.8}}>15</span><span style={{fontSize:mobile?22:35,maxWidth:240,lineHeight:1.05}}>biomarcadores.<br/>Una nueva<br/>perspectiva.</span></div>
    <div style={{width:w-pad*2,fontSize:mobile?25:42,lineHeight:1.12}}>Tus resultados, con contexto.<br/><span style={{fontFamily:'Georgia,serif',fontStyle:'italic'}}>Tu edad biológica. Tu evolución.</span><p style={{fontSize:mobile?16:18,lineHeight:1.4,maxWidth:420,marginTop:25}}>Repite tu análisis cada 90 días y descubre cómo cambian tus datos contigo.</p></div>
   </div>
  </AbsoluteFill>
  <AbsoluteFill data-layer="return-to-life" style={{background:'#0b1010',clipPath:`inset(${(1-exit)*50}% 0)`}}>
   <Img src="/art/stretch.jpg" style={{position:'absolute',height:'100%',width:mobile?'100%':'60%',left:mobile?'0':'22%',objectFit:'cover',maskImage:'radial-gradient(ellipse,black 15%,transparent 74%)',scale:range(f,710,840,1.18,1)}}/>
   <div style={{position:'absolute',left:pad,top:mobile?'27%':'26%',fontSize:mobile?w*.18:w*.115,letterSpacing:'-.07em',lineHeight:.97,translate:`0 ${range(f,735,800,60,0)}px`}}>Y volver<br/><span style={{fontFamily:'Georgia,serif',fontStyle:'italic'}}>a la vida.</span></div>
   <p style={{position:'absolute',right:pad,bottom:mobile?135:110,fontSize:mobile?18:23,lineHeight:1.3,maxWidth:mobile?230:310}}>Cuidarte. Y seguir<br/>haciendo lo que te mueve.</p>
  </AbsoluteFill>
 </AbsoluteFill>
}
