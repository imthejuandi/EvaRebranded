# EVA 03.20 / Approved still

Start from restored 03.19. Before extracting, move the two originals listed in RESTORE-03-20.json from their old paths to their new paths; remove the listed obsolete files. Extract the overlay. Original media bytes are unchanged. All earlier downloadable history archives are separate.
