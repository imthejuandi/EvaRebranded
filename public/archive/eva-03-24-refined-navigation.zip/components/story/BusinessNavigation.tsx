'use client';
import {useEffect,useLayoutEffect,useRef,useState} from 'react';
import {Popover} from '@base-ui/react/popover';
import {businessLinks} from '@/lib/landing-content';
import {DotMorphLabel} from './DotMorphLabel';

const links=[['Cómo funciona',businessLinks.method],['Ciencia',businessLinks.science],['Precios',businessLinks.pricing],['Nosotros',businessLinks.about]];

function NavigationLinks({className,label}:{className:string;label:string}){
 const nav=useRef<HTMLElement>(null);
 const [active,setActive]=useState<number|null>(null);
 const [light,setLight]=useState({x:0,y:0,width:0,height:0});
 useLayoutEffect(()=>{
  const root=nav.current;
  if(!root||active===null)return;
  const measure=()=>{
   const link=root.querySelectorAll<HTMLAnchorElement>(':scope > a')[active];
   if(link)setLight({x:link.offsetLeft,y:link.offsetTop,width:link.offsetWidth,height:link.offsetHeight});
  };
  measure();
  const resize=new ResizeObserver(measure);
  resize.observe(root);
  return()=>resize.disconnect();
 },[active]);
 const focused=()=>{
  const items=Array.from(nav.current?.querySelectorAll(':scope > a')??[]);
  const index=items.findIndex(link=>link.matches(':focus-visible'));
  return index<0?null:index;
 };
 return <nav ref={nav} className={className} aria-label={label}
  onPointerLeave={()=>setActive(focused())}
  onBlur={event=>{if(!event.currentTarget.contains(event.relatedTarget))setActive(null)}}>
  <span className="frost-light" aria-hidden="true" data-active={active!==null}
   style={{transform:`translate3d(${light.x}px,${light.y}px,0)`,width:light.width,height:light.height}}/>
  {links.map(([name,url],index)=><a key={url} href={url}
   onPointerEnter={event=>{if(event.pointerType==='mouse')setActive(index)}}
   onFocus={event=>{if(event.currentTarget.matches(':focus-visible'))setActive(index)}}>
   <DotMorphLabel>{name}</DotMorphLabel>
  </a>)}
 </nav>;
}

export function BusinessNavigation(){
 const [open,setOpen]=useState(false);
 useEffect(()=>{
  const desktop=matchMedia('(min-width: 901px)');
  const close=()=>{if(desktop.matches)setOpen(false)};
  desktop.addEventListener('change',close);
  return()=>desktop.removeEventListener('change',close);
 },[]);
 return <>
  <NavigationLinks className="business-nav frost-inline" label="EVA Health"/>
  <div className="business-menu">
   <Popover.Root open={open} onOpenChange={setOpen}>
    <Popover.Trigger className="frost-trigger">
     <DotMorphLabel selected={open}>Menú</DotMorphLabel>
     <span className="frost-trigger-mark" aria-hidden="true"/>
    </Popover.Trigger>
    <Popover.Portal>
     <Popover.Positioner side="bottom" align="center" sideOffset={12} collisionPadding={16} className="frost-positioner">
      <Popover.Popup className="frost-menu" aria-label="Explorar EVA" initialFocus={type=>type==='keyboard'}>
       <NavigationLinks className="frost-links" label="Explorar EVA"/>
      </Popover.Popup>
     </Popover.Positioner>
    </Popover.Portal>
   </Popover.Root>
  </div>
 </>;
}
