const clamp=(n:number)=>Math.max(0,Math.min(1,n));
const smooth=(n:number)=>{const t=clamp(n);return t*t*(3-2*t)};
const mix=(a:number,b:number,t:number)=>a+(b-a)*t;
export const lampSeed=(x:number,y:number)=>{const v=Math.sin(x*127.1+y*311.7+47.23)*43758.5453;return v-Math.floor(v)};
function noise(x:number,y:number){const ix=Math.floor(x),iy=Math.floor(y),u=smooth(x-ix),v=smooth(y-iy);return mix(mix(lampSeed(ix,iy),lampSeed(ix+1,iy),u),mix(lampSeed(ix,iy+1),lampSeed(ix+1,iy+1),u),v)}
/** One lamp material and one uninterrupted clock, irrespective of glyph membership. */
export function livingLamp(col:number,row:number,frame:number){
 const time=frame/36;
 const x=col*.15+Math.sin(row*.08+time*.33)*.38,y=row*.15+Math.cos(col*.08-time*.26)*.34;
 const field=noise(x+time*.32,y-time*.27)*.7+noise(x*2.1-time*.18,y*2.1+time*.14)*.3;
 const wave=smooth((field-.28)/.48);
 return {radius:(.22+.2*wave)*(.9+.1*lampSeed(col,row)),light:smooth((field-.35)/.32)};
}
