import {useId} from 'react';
import {AbsoluteFill,useCurrentFrame,useVideoConfig} from 'remotion';
import {bodySignalState,bodyTitleTravel,BODY_RESOLVE_END} from '@/lib/body-signal';
import {signalLabels,signalState} from '@/lib/analog-motion';
const descriptions=['Una mirada a lo que pasa dentro de ti.','Vuelve a conocerte. Observa cómo cambias.','Los datos son el principio. Tú decides cómo seguir.'];
const ease=(n:number)=>{const t=Math.max(0,Math.min(1,n));return t*t*(3-2*t)};
const q=(n:number)=>Math.round(n*100)/100;
const circle=(x:number,y:number,r:number)=>`M${q(x-r)},${q(y)}a${q(r)},${q(r)} 0 1,0 ${q(r*2)},0a${q(r)},${q(r)} 0 1,0 ${q(-r*2)},0`;
export function BodySignalFilm(){
 const frame=useCurrentFrame(),{width,height}=useVideoConfig(),mobile=width<700,pad=mobile?24:48;
 const state=bodySignalState(frame,width,height),board=signalState(Math.max(0,frame-BODY_RESOLVE_END));
 const id=useId().replace(/:/g,''),introFont=mobile?Math.min(width*.109,height*.059):width*.047,titleHeight=introFont*3.18;
 
 const titleTravel=bodyTitleTravel(frame);
 const buckets=Array.from({length:32},()=>[] as string[]);
 for(const p of state.points){
  const intensity=Math.round(p.opacity*31);
  if(intensity>0)buckets[intensity].push(circle(p.x,p.y,p.r));
 }
 const layers=buckets.map(paths=>paths.join(''));
 const textShadow='0 1px 2px #0b1010, 0 0 5px #0b1010';
 return <AbsoluteFill data-body-signal-frame={frame} data-body-signal-phase={state.phase} data-body-resolve={state.resolve.toFixed(3)} style={{background:'#0b1010',color:'#f3f0e8',fontFamily:'Arial,Helvetica,sans-serif',overflow:'hidden'}}>
  <div style={{position:'absolute',zIndex:1,textShadow,top:mobile?36:48,left:pad,right:pad,display:'flex',justifyContent:'space-between',gap:20,borderTop:'1px solid #f3f0e838',paddingTop:17,fontSize:mobile?11:12,letterSpacing:'.1em'}}><span>UNA SEÑAL PARA CONOCERTE</span><span>0{state.chapter+1} / 04</span></div>
  <div style={{position:'absolute',zIndex:1,textShadow,left:pad,top:mobile?'15%':'26%',width:mobile?width-pad*2:width*.43,height:titleHeight}}>
   <div style={{position:'absolute',inset:0,translate:`0 ${-18*titleTravel}px`,opacity:1-ease(titleTravel/.45),fontSize:introFont,letterSpacing:'-.055em',lineHeight:1.03}}>Interpretamos<br/>las señales<br/><span style={{fontFamily:'Georgia,serif',fontStyle:'italic'}}>de tu cuerpo.</span></div>
   <div style={{position:'absolute',inset:0,translate:`0 ${18*(1-titleTravel)}px`,opacity:ease((titleTravel-.55)/.45),fontSize:mobile?Math.min(width*.117,height*.065):width*.057,letterSpacing:'-.055em',lineHeight:1.03}}>De los datos.<br/><span style={{fontFamily:'Georgia,serif',fontStyle:'italic'}}>A tu vida.</span></div>
  </div>
  <svg data-body-field="full-bleed" viewBox={`0 0 ${width} ${height}`} style={{position:'absolute',inset:0,width:'100%',height:'100%',overflow:'hidden',zIndex:0}} aria-hidden="true">
   <defs><filter id={id+'-halo'} x="-25%" y="-25%" width="150%" height="150%"><feGaussianBlur stdDeviation={state.layout.pitch*.2}/></filter></defs>
   <g data-lamp-material="continuous-halftone">
    <g fill="#f3e4d5" filter={`url(#${id}-halo)`} opacity=".15">{layers.map((d,i)=>d?<path key={i} d={d} opacity={i/31}/>:null)}</g>
    <g fill="#f3f0e8">{layers.map((d,i)=>d?<path key={i} data-body-lamps="true" d={d} opacity={i/31}/>:null)}</g>
   </g>
  </svg>
  <div style={{position:'absolute',zIndex:1,textShadow,left:pad,top:mobile?undefined:'64%',bottom:mobile?106:undefined,maxWidth:mobile?width-48:310}}>
   <p style={{fontSize:mobile?23:28,letterSpacing:'-.03em',marginBottom:13}}>{state.phase==='data'?signalLabels[board.chapter]:'Cada señal cuenta.'}</p>
   <p style={{fontSize:16,lineHeight:1.5,maxWidth:300,color:'#bec4bb'}}>{state.phase==='data'?descriptions[board.chapter]:'De tus biomarcadores a una lectura de ti.'}</p>
  </div>
 </AbsoluteFill>;
}
