# Body Signal / EVA 03.10

The continuous surrounding field from 03.8 is restored. Numerals emerge more gradually from the same living lamps, while the field remains visible around them and behind readable mobile text.

## Reveal pacing

The opening remains a field until frame 165. Glyph guidance now develops across frames 165–390, instead of 165–270. A gentle downward delay plus fine per-lamp variation spreads the first traces through each stroke. Every lamp uses one smooth easing curve, avoiding the compressed middle caused by nesting two easing curves. All lamps complete their guidance together without an optical handoff.

The passage is 450svh tall and contains 751 frames. The reveal therefore spans 1.05 viewport heights of native scrolling, compared with 0.50 in 03.8. Copy moves over a separate 100-frame eased interval, using a small vertical drift and sequential opacity easing instead of clipping letters through a narrow window. Chapter navigation and subsequent numeral changes derive from the new reveal endpoint.

The renderer now uses 32 brightness groups. This halves the visible intensity increment while retaining the same sharp lamp core, subtle halo, radius function and uninterrupted clock. No new particles, layers or alternate numeral material are introduced. Each lamp remains in its original position.

## Character and legibility

Angular 5×7 silhouettes retain stepped shoulders, counters and a slashed zero. The 15 / 90 / TÚ glyphs retain 675 / 875 / 670 sites; surrounding lamps remain visible after resolution. Later numbers retain the accepted individual-lamp switching.

The field fills all four edges on mobile, including behind copy. The existing soft brightness veil and local text shadow protect readability. Reduced motion retains the static halftone presentation. The specimen and frame inspector are at `/system#body-signal`; the supplied reference remains `/art/reference-body-signal.mp4`.

## Bounded review

Automated checks cover all 751 frames, exact lamp positions and radius function, deterministic reverse reconstruction, full-screen mobile coverage, bounded brightness behind text, and clear numeral contrast. Every numeral lamp's guidance is monotonic and increases by less than 0.9 percentage points per frame. Text movement has eased endpoints and bounded increments. The reveal boundary and all derived navigation stops are checked.

Rendered early, midpoint, settled desktop and compact-mobile transition frames were reviewed. The compact midpoint exposed clipped letter fragments; the title now leaves and enters as whole lines. An independent review approved the dot progression. Live chapter controls and native scrolling are checked in the local preview. These targeted checks do not constitute an assistive-technology audit. Existing analog, content, delivery, TypeScript and build checks remain part of verification.

03.9's isolated-number alternative is retained at `/archive/eva-03-9-numeral-centerpiece.zip`. The preferred continuous-field baseline remains at `/archive/eva-03-8-continuous-field.zip`. All earlier versions remain available in `/history`.
