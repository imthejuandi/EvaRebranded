EVA 03.4 Soft Glass source and assets, before the Body Signal passage. Earlier ZIP archives are available separately on the study history page.
