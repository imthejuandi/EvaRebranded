# Method Journey / EVA03.12

Four user-selected chapters pair a large visual with the existing method information. The neutral paper section and typography remain part of EVA's accepted system. Contained colors are used inside the artwork.

References inspected: [Sapiens by Studio Airport](https://savee.com/i/kmIYP2u/) for editorial pacing and [Compound healthcare branding](https://savee.com/i/czimi4b/) for image-led chapters. This is an original implementation of those principles, with EVA's official Tasso+ placement image and bespoke lightweight SVG illustrations. No third-party code or image is copied into the component.

`MethodJourney` imports all four `methodSteps` unchanged. All steps are in the initial HTML. Tabs support Left/Right, Home/End and roving keyboard focus. Previous/next controls provide the same selection on touch. The selected tab is connected to its panel. No autoplay or forced progression. Reduced motion disables the short entrance and underline motion. No animation library or continuous rendering loop is added.

Mobile artwork is compact and text follows in normal flow. Desktop pairs the visual with the active step, retaining the four navigation labels. Tasso art uses responsiveWebP derivatives; the originalPNG stays in the archive and asset library.

Verified at320px and1440px: one active panel, no horizontal page overflow, keyboard selection, previous/next control behavior, original business wording and readable contrast. These are targeted checks, not a complete assistive-technology audit.
