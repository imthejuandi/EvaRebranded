# Tasso+ / Aire libre — EVA03.12

The accepted coastal walk is retained frame for frame. A cutout of the official Tasso+ product photograph follows each exposed outer upper arm. Its scale follows the people as they approach; its rotation, warm color and fine grain fit the surrounding image. The faces, gaze, path, camera and trailing glow come from the original accepted footage.

Two generative edits were rejected for oversized devices and intermittent disappearance. The selected result uses controlled compositing, with reviewed half-second anchors and optical-flow refinements bounded to4pixels. Both devices remain visible until their corresponding arm leaves the frame. The comparison sheets include quarter-second tracking checks. This is a product placement within a lifestyle illustration.

The web asset is720×1280,H.264,24fps,221frames,9.208seconds,silent and fast-start. It plays once, offers pause and replay, and pauses outside the viewport. Its source is attached only near the viewport. Responsive600/1000WebP posters provide a lightweight still and reduced-motion alternative.

## Reuse

The source footage is `/art/post-run-coast-walk-cut.mp4`; the product reference is `/art/tasso-plus-product.jpg`. The accepted output is `/art/post-run-coast-tasso-walk-v1.mp4`. Previous artwork remains available in `/history`.

Download `/review/tasso-walk-composite.py` and `/review/tasso-walk-tracking.json`. The script was executed in the Higgsfield Linux media sandbox with OpenCV,NumPy,Pillow andFFmpeg. It expects the original footage as`source.mp4` and the product reference as`product.jpg` in its working directory. It includes the reviewed anchor points, cutout preparation, warm treatment, output encoding and review sheets. The tracking file preserves the221-frame coordinates, scales and rotations for both devices.

Full decode, source/output frame count, silent playback and fast-start checks passed. Desktop/phone-width layout and native play/replay were checked in the landing preview. The source is stylized and the product remains small at long distance.
