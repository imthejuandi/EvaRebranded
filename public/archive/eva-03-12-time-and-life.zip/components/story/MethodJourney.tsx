'use client';

import {useRef, useState, type KeyboardEvent} from 'react';
import {businessLinks, methodSteps} from '@/lib/landing-content';

// Visual references: Studio Airport / Sapiens (savee.com/i/kmIYP2u/)
// and Compound healthcare branding (savee.com/i/czimi4b/).
// All business wording comes from the existing landing-content module.
const chapters = ['En casa', 'Tu base', 'Contexto', 'Qué sigue'];
const captions = [
  ['TASSO+', 'RECOGIDA EN CASA'],
  ['15 BIOMARCADORES', 'CADA 3 MESES'],
  ['TU LECTURA', 'EN PERSPECTIVA'],
  ['CADA 90 DÍAS', 'VUELVE A CONOCERTE'],
];

function JourneyArrow({back = false}: {back?: boolean}) {
  return <svg viewBox="0 0 24 24" width="24" height="24" fill="none" aria-hidden="true" focusable="false" style={back ? {transform: 'rotate(180deg)'} : undefined}><path d="M4 12h15m-6-6 6 6-6 6" stroke="currentColor" strokeWidth="1.35"/></svg>;
}

function MethodArtwork({step}: {step: number}) {
  if (step === 0) return <div className="method-portrait">
    <span className="method-portrait-disc" aria-hidden="true"/>
    <img src="/art/tasso-plus-in-use-1000.webp" srcSet="/art/tasso-plus-in-use-600.webp 600w, /art/tasso-plus-in-use-1000.webp 1000w" sizes="(max-width:700px) 90vw, 50vw" alt="Tasso+ colocado en la parte superior del brazo" loading="lazy" decoding="async" width="1220" height="1566"/>
  </div>;

  if (step === 1) return <svg className="method-artwork" viewBox="0 0 520 570" aria-hidden="true" focusable="false">
    <path d="M54 440h412" stroke="#465346" strokeOpacity=".35"/>
    {[0, 1, 2, 3].map(quarter => <g key={quarter} transform={`translate(${50 + quarter * 105} ${102 + quarter * 28})`}>
      <rect width="104" height="256" rx="2" fill={['#d9cbb3', '#ead9c1', '#f4e9d6', '#fff7e8'][quarter]} stroke="#465346" strokeOpacity=".36"/>
      <text x="16" y="30" fill="#354635" fontFamily="Arial, Helvetica, sans-serif" fontSize="10" letterSpacing="1">LECTURA 0{quarter + 1}</text>
      {Array.from({length: 15}, (_, marker) => <circle key={marker} cx={22 + marker % 3 * 30} cy={70 + Math.floor(marker / 3) * 31} r="7" fill="#526a51" opacity={quarter === 3 ? 1 : .6}/>) }
      <path d="M16 230h72" stroke="#465346" strokeOpacity=".3"/>
    </g>)}
    <text x="55" y="504" fill="#354635" fontFamily="Georgia, serif" fontSize="42" letterSpacing="-2">Una trayectoria.</text>
  </svg>;

  if (step === 2) return <div className="method-context-art" aria-hidden="true">
    <svg className="method-artwork" viewBox="0 0 520 570" focusable="false">
      <circle cx="219" cy="242" r="151" fill="#876b85"/>
      <circle cx="325" cy="272" r="128" fill="#cb8878"/>
      <circle cx="245" cy="337" r="126" fill="#d6bf98"/>
      <circle cx="264" cy="288" r="48" fill="#f3f0e8"/>
      {Array.from({length: 15}, (_, i) => <circle key={i} cx={244 + i % 3 * 20} cy={248 + Math.floor(i / 3) * 20} r="3" fill="#493a48"/>)}
      <path d="M117 97h89M369 127v69M398 414h-78" stroke="#483b48" strokeWidth="1"/>
      <circle cx="117" cy="97" r="3" fill="#483b48"/><circle cx="369" cy="127" r="3" fill="#483b48"/><circle cx="398" cy="414" r="3" fill="#483b48"/>
    </svg>
    <div className="method-context-labels"><span>Rangos de longevidad</span><span>Edad biológica estimada</span><span>Puntuación de longevidad</span></div>
  </div>;

  return <svg className="method-artwork" viewBox="0 0 520 570" aria-hidden="true" focusable="false">
    <circle cx="260" cy="275" r="171" fill="none" stroke="#9b674c" strokeOpacity=".44"/>
    <path d="M260 104a171 171 0 0 1 171 171" fill="none" stroke="#71442e" strokeWidth="3"/>
    {[[260, 104], [431, 275], [260, 446], [89, 275]].map(([x, y], i) => <g key={i}><circle cx={x} cy={y} r="24" fill={i === 0 ? '#71442e' : '#edcdb1'} stroke="#9b674c"/><circle cx={x} cy={y} r="3" fill={i === 0 ? '#f8eddc' : '#71442e'}/></g>)}
    <text x="250" y="316" textAnchor="middle" fill="#71442e" fontFamily="Georgia, serif" fontSize="140" letterSpacing="-14">90</text>
    <text x="260" y="351" textAnchor="middle" fill="#71442e" fontFamily="Arial, Helvetica, sans-serif" fontSize="12" letterSpacing="4">DÍAS</text>
    <path d="m421 263 10 12 11-12" fill="none" stroke="#71442e" strokeWidth="1.6"/>
  </svg>;
}

export function MethodJourney({calm = false}: {calm?: boolean}) {
  const [active, setActive] = useState(0);
  const tabs = useRef<Array<HTMLButtonElement | null>>([]);

  function selectStep(index: number, focus = false) {
    const next = Math.max(0, Math.min(methodSteps.length - 1, index));
    setActive(next);
    if (focus) tabs.current[next]?.focus();
  }

  function handleKey(event: KeyboardEvent<HTMLButtonElement>, index: number) {
    let next: number;
    if (event.key === 'ArrowRight') next = (index + 1) % methodSteps.length;
    else if (event.key === 'ArrowLeft') next = (index + methodSteps.length - 1) % methodSteps.length;
    else if (event.key === 'Home') next = 0;
    else if (event.key === 'End') next = methodSteps.length - 1;
    else return;
    event.preventDefault();
    selectStep(next, true);
  }

  return <section className={'method-journey' + (calm ? ' method-journey-calm' : '')} id="el-metodo" aria-labelledby="routine-title">
    <div className="section-kicker"><span>03 / EL MÉTODO</span><span>UN MOMENTO PARA TI.</span></div>
    <div className="method-heading">
      <h2 id="routine-title">Cuatro pasos.<br/><em>A tu ritmo.</em></h2>
      <p>Recogida de muestra en casa. Análisis en laboratorio acreditado. Y una nueva lectura de ti, cada 90 días.</p>
    </div>

    <div className="method-chapters" role="tablist" aria-label="Los cuatro pasos de EVA" aria-orientation="horizontal">
      {methodSteps.map((step, index) => <button
        key={step.title}
        ref={node => { tabs.current[index] = node; }}
        id={`method-tab-${index}`}
        role="tab"
        type="button"
        aria-selected={active === index}
        aria-controls={`method-panel-${index}`}
        aria-label={`Paso ${index + 1}, ${chapters[index]}: ${step.title}`}
        tabIndex={active === index ? 0 : -1}
        onClick={() => selectStep(index)}
        onKeyDown={event => handleKey(event, index)}
      ><span className="method-chapter-index">0{index + 1}</span><span>{chapters[index]}</span><i aria-hidden="true"/></button>)}
    </div>

    {methodSteps.map((step, index) => <div
      key={step.title}
      className="method-panel"
      id={`method-panel-${index}`}
      role="tabpanel"
      aria-labelledby={`method-tab-${index}`}
      hidden={active !== index}
      tabIndex={0}
    >
      <figure className={`method-figure method-figure-${index}`}>
        <div className="method-figure-stage"><MethodArtwork step={index}/></div>
        <figcaption><span>{captions[index][0]}</span><span>{captions[index][1]}</span></figcaption>
      </figure>
      <div className="method-chapter-copy">
        <p className="method-page-number" aria-hidden="true">0{index + 1}<span>/ 04</span></p>
        <div className="method-chapter-body"><h3>{step.title}</h3><p>{step.copy}</p></div>
        <div className="method-paging" role="group" aria-label="Recorrer los pasos">
          <button type="button" aria-label="Paso anterior" disabled={index === 0} onClick={() => selectStep(index - 1, true)}><JourneyArrow back/><span>Anterior</span></button>
          <button type="button" aria-label="Siguiente paso" disabled={index === methodSteps.length - 1} onClick={() => selectStep(index + 1, true)}><span>Siguiente</span><JourneyArrow/></button>
        </div>
        <a className="method-detail-link" href={businessLinks.method}>Así funciona EVA <JourneyArrow/></a>
      </div>
    </div>)}
  </section>;
}
