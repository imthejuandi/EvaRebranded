import {useLayoutEffect,useRef} from 'react';
import type {bodySignalState} from '@/lib/body-signal';

type SignalState=ReturnType<typeof bodySignalState>;

/** The same lamps, drawn once into a retained surface instead of serialized SVG paths. */
export function BodySignalCanvas({state}:{state:SignalState}){
 const canvas=useRef<HTMLCanvasElement>(null),buffer=useRef<HTMLCanvasElement|null>(null);
 useLayoutEffect(()=>{
  const el=canvas.current;if(!el)return;
  const start=performance.now(),{width,height,pitch}=state.layout;
  const ratio=Math.min(2,window.devicePixelRatio||1),w=Math.round(width*ratio),h=Math.round(height*ratio);
  const surface=buffer.current??(buffer.current=document.createElement('canvas'));
  if(el.width!==w||el.height!==h){el.width=w;el.height=h;surface.width=w;surface.height=h;}
  const ctx=el.getContext('2d'),ink=surface.getContext('2d');if(!ctx||!ink)return;
  ink.setTransform(ratio,0,0,ratio,0,0);ink.clearRect(0,0,width,height);ink.fillStyle='#f3f0e8';
  const buckets=Array.from({length:32},()=>[] as SignalState['points']);
  for(const point of state.points)buckets[Math.round(point.opacity*31)].push(point);
  for(let i=1;i<32;i++){
   ink.globalAlpha=i/31;ink.beginPath();
   for(const p of buckets[i]){ink.moveTo(p.x+p.r,p.y);ink.arc(p.x,p.y,p.r,0,Math.PI*2);}
   ink.fill();
  }
  ctx.setTransform(1,0,0,1,0,0);ctx.clearRect(0,0,w,h);
  // One restrained halo for the combined field; never a filter per lamp.
  ctx.globalAlpha=.15;ctx.filter=`blur(${pitch*.2*ratio}px)`;ctx.drawImage(surface,0,0);
  ctx.filter='none';ctx.globalAlpha=1;ctx.drawImage(surface,0,0);
  el.dataset.drawMs=(performance.now()-start).toFixed(2);
 },[state]);
 return <canvas ref={canvas} data-body-field="full-bleed" data-lamp-material="continuous-halftone" data-lamp-count={state.points.length} aria-hidden="true" style={{position:'absolute',inset:0,width:'100%',height:'100%',zIndex:0}}/>;
}
