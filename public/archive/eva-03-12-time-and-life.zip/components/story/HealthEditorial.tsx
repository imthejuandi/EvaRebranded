import {Arrow} from './Arrow';
import {businessLinks} from '@/lib/landing-content';
import {DotNumber} from './DotNumber';
import {BiomarkerGallery} from './BiomarkerGallery';
import {LifestylePassage} from './LifestylePassage';
import {MethodJourney} from './MethodJourney';

export function HealthEditorial({calm=false}:{calm?:boolean}){return <>
 <section className="context-passage" id="una-perspectiva" aria-labelledby="context-title">
  <div className="section-kicker"><span>01 / UNA MIRADA MÁS AMPLIA</span><a href={businessLinks.science}>LA CIENCIA DE EVA</a></div>
  <div className="context-grid"><h2 id="context-title">Tu cuerpo es más<br/>que un resultado<br/><em>«normal».</em></h2><div className="context-copy"><p>Los intervalos de referencia describen una población. Tu salud también tiene una historia propia: cómo te encuentras, tus hábitos y la forma en que cambias.</p><p>EVA añade una perspectiva de longevidad a tus biomarcadores. Una base para conocerte mejor, leída cada 3 meses. Porque una trayectoria cuenta más que una fotografía aislada.</p><a className="text-link" href={businessLinks.science}>Entender los rangos de EVA </a></div></div>
  <div className="annual-reading"><div className="annual-number"><DotNumber value="60" calm={calm}/><p>puntos de información al año</p></div><div className="annual-rhythm"><p><b>15 biomarcadores.</b><br/>Cuatro momentos para volver a ti.</p><div className="quarter-track" aria-label="Cuatro lecturas, una cada tres meses">{['01','04','07','10'].map((m,i)=><div key={m}><span className="quarter-dots" aria-hidden="true">{Array.from({length:15},(_,j)=><i key={j}/>)}</span><span>MES {m}</span><small>{i===0?'Tu punto de partida':'Tu siguiente lectura'}</small></div>)}</div></div></div>
 </section>
 <BiomarkerGallery calm={calm}/>
 <MethodJourney calm={calm}/>
 <LifestylePassage calm={calm}/>
 <section className="age-passage" id="tu-evolucion" aria-labelledby="age-title"><div className="section-kicker"><span>04 / TU EVOLUCIÓN</span><span>UNA NUEVA LECTURA CADA TRIMESTRE</span></div><div className="age-heading"><h2 id="age-title">Tu edad cuenta<br/><em>una parte.</em></h2><div><p>Tu fecha de nacimiento es solo el principio. La edad biológica ofrece otra perspectiva sobre tu cuerpo.</p><p>EVA estima tu edad biológica y calcula una puntuación de longevidad. Al repetir la lectura cada trimestre, puedes seguir su evolución junto a tus cambios de hábitos.</p></div></div><div className="age-readings"><div><p>EN TU CARNET</p><DotNumber value="34" calm={calm}/><span>años</span></div><div className="age-connector" aria-hidden="true"><Arrow/></div><div><p>EDAD BIOLÓGICA ESTIMADA</p><DotNumber value="29" calm={calm}/><span>años</span></div></div><div className="age-foot"><p><span>−5</span> años en este ejemplo.<br/>Otra forma de observar tu evolución.</p><p className="illustration-note">Ejemplo ilustrativo, no una predicción de tu resultado. La edad biológica es una estimación y es distinta de tu puntuación de longevidad.</p></div></section>
 <section className="manifesto full-founder" id="nuestra-historia"><p className="eyebrow">05 / UNA IDEA MUY PERSONAL</p><blockquote>«EVA es el servicio que deseaba tener cuando comencé mi propio camino de salud preventiva: uno que no solo te entrega datos, sino que te enseña lo que significan <em>y qué hacer al respecto.»</em></blockquote><div className="founder"><span>Juan Diego Lago<br/><small>Fundador y CEO, EVA Health</small></span><a className="text-link" href={businessLinks.about}>Nuestra historia</a></div></section>
 </>}
