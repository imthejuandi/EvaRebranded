/** The approved natural-skin Solar Glow still, without video playback. */
export function MethodPouchStill({calm}:{calm:boolean}) {
  return <div className={'method-home-art method-pouch-still'+(calm?' is-calm':'')}>
    <img
      src="/art/method-pouch-still-1000.webp"
      srcSet="/art/method-pouch-still-600.webp 600w, /art/method-pouch-still-1000.webp 1000w"
      sizes="(max-width: 700px) calc(100vw - 48px), 50vw"
      width={1000} height={1099} loading="lazy" decoding="async"
      alt="Una mujer con ropa deportiva sostiene un pequeño Tasso+ sobre una bolsa EVA, entre luz melocotón y sombras violetas."
    />
    <span className="method-home-line">Un momento en tu día.</span>
  </div>;
}
