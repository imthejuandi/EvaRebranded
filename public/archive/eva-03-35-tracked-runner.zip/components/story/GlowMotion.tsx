'use client';

import {useEffect,useRef,useState,type CSSProperties} from 'react';
import {Html5Video,Img,staticFile,useRemotionEnvironment} from 'remotion';

export const glowMotionStyle={
 background:'#0b1010',
 mask:'radial-gradient(ellipse,black 36%,transparent 73%)',
 colorLanguage:'amber / lilac / blue',
 texture:'optical defocus, bloom and fine grain in the source asset',
} as const;

type GlowMotionProps={
 poster:string;
 posterSrcSet?:string;
 priority?:boolean;
 video?:string;
 alt?:string;
 enabled?:boolean;
 active?:boolean;
 inComposition?:boolean;
 className?:string;
 style?:CSSProperties;
 mask?:string;
 onPlaybackBlocked?:()=>void;
 onMediaError?:()=>void;
 loop?:boolean;
 replayKey?:number;
 onEnded?:()=>void;
};

/** Source-led optical artwork. Scroll controls its parent; only the living texture follows time. */
export function GlowMotion({poster,posterSrcSet,priority=false,video,alt='',enabled=true,active=true,inComposition=false,className,style,mask=glowMotionStyle.mask,onPlaybackBlocked,onMediaError,loop=true,replayKey=0,onEnded}:GlowMotionProps){
 const environment=useRemotionEnvironment();
 const timedComposition=environment.isStudio||environment.isRendering;
 const native=!timedComposition&&!environment.isClientSideRendering;
 const container=useRef<HTMLDivElement>(null),media=useRef<HTMLVideoElement>(null);
 const blockedCallback=useRef(onPlaybackBlocked);
 useEffect(()=>{blockedCallback.current=onPlaybackBlocked},[onPlaybackBlocked]);
 const [reduced,setReduced]=useState(true),[inView,setInView]=useState(false),[visible,setVisible]=useState(true),[near,setNear]=useState(false);
 const [ready,setReady]=useState(false),[failed,setFailed]=useState(false),[playing,setPlaying]=useState(false);
 useEffect(()=>{setReady(false);setFailed(false)},[video,replayKey]);
 useEffect(()=>{const query=matchMedia('(prefers-reduced-motion: reduce)');const sync=()=>setReduced(query.matches);sync();query.addEventListener('change',sync);return()=>query.removeEventListener('change',sync)},[]);
 useEffect(()=>{const el=container.current;if(!el)return;const observer=new IntersectionObserver(entries=>setInView(entries[0]?.isIntersecting??false));observer.observe(el);const warm=new IntersectionObserver(entries=>{if(entries[0]?.isIntersecting){setNear(true);warm.disconnect()}},{rootMargin:'400px'});warm.observe(el);const sync=()=>setVisible(document.visibilityState==='visible');sync();document.addEventListener('visibilitychange',sync);return()=>{observer.disconnect();warm.disconnect();document.removeEventListener('visibilitychange',sync)}},[]);
 const sourceReady=(near||priority)&&!reduced;
 const shouldPlay=native&&sourceReady&&enabled&&active&&inView&&visible&&!failed;
 useEffect(()=>{const el=media.current;if(!el)return;let cancelled=false;if(shouldPlay){void el.play().catch((error:unknown)=>{if(cancelled||(error instanceof DOMException&&error.name==='AbortError'))return;setPlaying(false);blockedCallback.current?.()})}else el.pause();return()=>{cancelled=true;el.pause()}},[shouldPlay,video,replayKey]);
 const fill:CSSProperties={position:'absolute',inset:0,width:'100%',height:'100%',objectFit:'cover'};
 return <div ref={container} className={className} data-glow-motion data-glow-state={failed?'fallback':playing?'playing':'paused'} style={{position:'relative',width:'100%',height:'100%',overflow:'hidden',maskImage:mask,...style}}>
  {timedComposition&&inComposition?<Img src={poster.startsWith('/')?staticFile(poster):poster} alt={alt} style={fill}/>:<img src={poster} srcSet={posterSrcSet} sizes={priority?"(max-width: 700px) 90vw, 31vw":"(max-width: 700px) 100vw, 50vw"} loading={priority?"eager":"lazy"} decoding="async" fetchPriority={priority?"high":"auto"} alt={alt} style={fill}/>}
  {video&&timedComposition&&enabled&&active&&<Html5Video src={video.startsWith('/')?staticFile(video):video} muted loop={loop} style={fill}/>}
  {video&&native&&<video key={replayKey} ref={media} src={sourceReady?video:undefined} muted loop={loop} playsInline preload={sourceReady?"auto":"none"} aria-hidden="true" disablePictureInPicture onPlaying={()=>{setReady(true);setPlaying(true)}} onPause={()=>setPlaying(false)} onEnded={()=>{setPlaying(false);onEnded?.()}} onError={()=>{setFailed(true);setReady(false);onMediaError?.()}} style={{...fill,opacity:ready&&!reduced?1:0}}/>}
 </div>
}
