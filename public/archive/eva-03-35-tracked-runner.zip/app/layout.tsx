import type {Metadata} from 'next';
import './globals.css';
export const metadata:Metadata={title:'EVA — Conoce tu salud.',description:'15 biomarcadores cada 90 días. Recogida de muestra en casa, análisis en laboratorio acreditado. Entiende tus resultados y sigue tu evolución con EVA.'};
export default function Layout({children}:{children:React.ReactNode}){return <html lang="es"><head><link rel="preload" href="/fonts/hanken-grotesk-regular.woff" as="font" type="font/woff" crossOrigin="anonymous"/></head><body>{children}</body></html>}
