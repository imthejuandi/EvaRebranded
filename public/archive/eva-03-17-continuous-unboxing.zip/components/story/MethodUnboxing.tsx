'use client';

import {useState} from 'react';
import {GlowMotion} from './GlowMotion';

/** A continuous unboxing edit guided by the native product model. */
export function MethodUnboxing({visible,calm}:{visible:boolean;calm:boolean}) {
  const [paused,setPaused]=useState(false),[ended,setEnded]=useState(false);
  const [failed,setFailed]=useState(false),[cycle,setCycle]=useState(0);
  const label=ended?'Ver de nuevo':paused?'Reproducir':'Pausar';
  function toggle(){
    if(ended){setCycle(value=>value+1);setEnded(false);setPaused(false)}
    else setPaused(value=>!value);
  }
  return <div className={'method-home-art method-unboxing'+(calm?' is-calm':'')} data-method-playback={failed?'fallback':ended?'ended':paused?'paused':'ready'}>
    <GlowMotion
      poster="/art/method-unboxing-continuous-1000.jpg"
      posterSrcSet="/art/method-unboxing-continuous-600.jpg 600w, /art/method-unboxing-continuous-1000.jpg 1000w"
      video={calm?undefined:'/art/method-unboxing-continuous-720.mp4'}
      alt="Una mujer levanta la tapa de una caja y descubre un Tasso+ en su interior, entre luz coral y sombras violetas."
      mask="none" loop={false} replayKey={cycle}
      enabled={!calm&&!paused&&!ended} active={visible}
      onEnded={()=>setEnded(true)} onPlaybackBlocked={()=>setPaused(true)} onMediaError={()=>setFailed(true)}
    />
    <span className="method-home-line">Un momento en tu día.</span>
    {!calm&&!failed&&<button className="method-video-control" type="button" onClick={toggle} aria-label={`${label} el vídeo de la caja con Tasso+`}>
      <svg viewBox="0 0 18 18" width="16" height="16" aria-hidden="true" fill="none">{paused||ended?<path d="m6 3 8 6-8 6Z" stroke="currentColor" strokeWidth="1.2"/>:<path d="M6 3v12m6-12v12" stroke="currentColor" strokeWidth="1.4"/>}</svg>{label}
    </button>}
  </div>;
}
