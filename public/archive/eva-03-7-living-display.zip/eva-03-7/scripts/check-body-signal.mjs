import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {readFileSync} from 'node:fs';
import {bodySignalState,BODY_SIGNAL_DURATION,BODY_RESOLVE_END,bodySignalStops} from '../lib/body-signal.ts';
import {halftoneState,halftoneMasks,HALFTONE_COLS,HALFTONE_ROWS,HALFTONE_PITCH} from '../lib/halftone-motion.ts';
import {signalStops} from '../lib/analog-motion.ts';
import {productHover} from '../lib/product-motion.ts';
const hash=s=>createHash('sha256').update(JSON.stringify(s)).digest('hex');
const coords=s=>s.points.map(({x,y})=>({x,y}));
const frames=[],positions=coords(bodySignalState(0));
let previous,maxChange=0;
for(let f=0;f<BODY_SIGNAL_DURATION;f++){
 const state=bodySignalState(f),pitch=state.layout.pitch;
 assert.deepEqual(coords(state),positions,'All lamps must remain registered across the whole screen');
 assert(state.points.every(p=>Number.isFinite(p.r)&&p.r>=0&&p.r<pitch*.58));
 if(previous&&f<BODY_RESOLVE_END)maxChange=Math.max(maxChange,...state.points.map((p,i)=>Math.abs(p.r-previous.points[i].r)/pitch));
 previous=state;frames.push(hash(state));
 if(f>=BODY_RESOLVE_END){
  const expected=halftoneState(f-BODY_RESOLVE_END).points;
  for(const p of state.points){
   const col=Math.round((p.x-state.layout.left)/pitch),row=Math.round((p.y-state.layout.top)/pitch);
   const i=col>=0&&col<HALFTONE_COLS&&row>=0&&row<HALFTONE_ROWS?row*HALFTONE_COLS+col:-1;
   const on=i>=0&&expected[i].r>0;
   assert.equal(p.r>pitch*.1,on,'Bright lamps must preserve angular glyphs while the faint field remains outside');
  }
 }
}
assert(maxChange<.035,'The field must resolve without a flash');
for(const [w,h] of [[1440,900],[390,844],[320,568]]){
 const state=bodySignalState(75,w,h),p=state.points,pitch=state.layout.pitch;
 assert(Math.min(...p.map(p=>p.x))<0&&Math.max(...p.map(p=>p.x))>w);
 assert(Math.min(...p.map(p=>p.y))<0&&Math.max(...p.map(p=>p.y))>h,'Field extends beyond every viewport edge');
 assert(p.filter(p=>p.r>pitch*.3).length>30,'Keep coherent luminous regions');
 assert(p.some(p=>p.x<state.layout.left-pitch&&p.r>pitch*.1),'Light must exist outside the number area');
 const title=p.filter(p=>w<700?p.x>30&&p.x<w-30&&p.y>h*.17&&p.y<h*.29:p.x>50&&p.x<430&&p.y>250&&p.y<425);
 assert(title.every(p=>p.r<pitch*.09),'Protect title contrast with a soft quiet area');
}
assert.deepEqual(halftoneMasks.map(mask=>mask.filter(Boolean).length),[675,875,670],'Preserve 5x7 shoulders, counters, slashed zero and accent');
for(const f of signalStops){
 const active=halftoneState(f).points.filter(p=>p.r>0);
 assert(new Set(active.map(p=>p.r.toFixed(3))).size>20,'Retain varied halftone lamp weights');
 assert(active.every(p=>p.r*2<HALFTONE_PITCH*.87),'Keep visible gaps');
}
const a=halftoneState(0).points,b=halftoneState(160).points,mid=halftoneState(95).points;
const changing=a.map((_,i)=>i).filter(i=>(a[i].r>0)!==(b[i].r>0));
assert(changing.some(i=>(mid[i].r>0)===(a[i].r>0))&&changing.some(i=>(mid[i].r>0)===(b[i].r>0)),'Individual lamps switch, not whole words');
assert.notDeepEqual(halftoneState(0).points,halftoneState(20).points,'Settled lamps retain a gentle phosphor pulse');
assert.deepEqual(bodySignalStops,[0,...signalStops.map(f=>f+BODY_RESOLVE_END)]);
for(let f=BODY_SIGNAL_DURATION-1;f>=0;f--)assert.equal(hash(bodySignalState(f)),frames[f]);
for(let f=0;f<841;f++){assert(Math.abs(productHover(f))<=8);assert(Math.abs(productHover(f+1)-productHover(f))<.34)}
const film=readFileSync('components/story/BodySignalFilm.tsx','utf8');
assert(film.includes('data-body-field="full-bleed"')&&!film.includes('scaleX')&&!film.includes('state.resolve===1&&<path'),'No bounded square, scaling field, or uniform off-dot grid');
console.log(`Body Signal passed: ${BODY_SIGNAL_DURATION} reversible full-screen frames; mobile/desktop title contrast; angular 5x7 masks, individual switching and varied pulsing dots; gentle Tasso hover.`);
