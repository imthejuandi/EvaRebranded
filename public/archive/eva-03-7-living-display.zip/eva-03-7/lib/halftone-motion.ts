import {analogGlyphs} from './analog-motion.ts';
export const HALFTONE_COLS=55,HALFTONE_ROWS=41,HALFTONE_PITCH=.2;
export const HALFTONE_VIEWBOX='-.22 -.22 11.24 8.44';
const clamp=(n:number)=>Math.max(0,Math.min(1,n));
const seed=(i:number)=>{const v=Math.sin(i*127.13+63.71)*43758.5453;return v-Math.floor(v)};
const sites=Array.from({length:HALFTONE_COLS*HALFTONE_ROWS},(_,i)=>({x:(i%HALFTONE_COLS)*HALFTONE_PITCH,y:Math.floor(i/HALFTONE_COLS)*HALFTONE_PITCH}));
export const halftoneMasks=['15','90','TÚ'].map(word=>sites.map((_,i)=>{
 const col=i%HALFTONE_COLS,row=Math.floor(i/HALFTONE_COLS),letterIndex=Math.floor(col/30),local=col-letterIndex*30;
 if(letterIndex>1||local>=25)return false;
 if(row<6)return word[letterIndex]==='Ú'&&row>=1&&row<=4&&local>=15&&local<20;
 return analogGlyphs[word[letterIndex]][Math.floor((row-6)/5)]?.[Math.floor(local/5)]==='1';
}));
export function halftoneState(frame:number){
 const f=Math.max(0,Math.min(360,frame));
 const phase=f<160?clamp((f-55)/80):1+clamp((f-215)/80);
 const from=Math.min(1,Math.floor(phase)),to=Math.min(2,from+1),step=Math.floor((phase-from)*8)/8;
 const points=sites.map((p,i)=>{
  const switched=step>=1||step>((i*7)%17)/16;
  const on=halftoneMasks[switched?to:from][i];
  // The angular bitmap is preserved. Each lamp has its own optical weight and soft phosphor pulse.
  const local=.72+.28*seed(i),light=.76+.24*Math.sin(p.x*.56+p.y*.36+f*.012)**2;
  const pulse=.965+.035*Math.sin(f*.043+p.x*.7+p.y*.5+seed(i)*2);
  return {...p,r:on?.086*local*light*pulse:0};
 });
 return {chapter:phase<.5?0:phase<1.5?1:2,points};
}
