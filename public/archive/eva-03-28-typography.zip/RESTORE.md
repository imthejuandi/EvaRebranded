# Restore EVA 03.28

Apply these files over 03.27 (10d5b3ee0c02a805f32f8913aac965c7ff7a6fa0). This restores source commit 27722b69b23610efd45a52be0bbcac0b7a9c6d2e.

No files were deleted. Retain the existing public/archive files; they are deliberately excluded from this update to avoid recursive archives.

The previous hero hierarchy and fine menu dot grid are preserved.
