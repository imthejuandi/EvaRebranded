# EVA design context

This is an independent design study, not the production EVA business site or app.

Use ink #0b1010, warm paper #f3f0e8, amber #e9a067, the approved soft-glow imagery, and existing analog lettering. The official EVA artwork supplies its exact geometry and spacing.

The user selected the supplied Sterling Gate kinetic navigation on 2026-09-12. It replaces the compact frosted dropdown with a layered side panel, staggered links, a rotating close control, and ambient shapes. Preserve the four business destinations and EN in the page header. The existing dot-letter effect remains on link interactions. Use Base UI for dialog behavior and scoped GSAP timelines, with reduced motion, keyboard access, and no idle animation loop.

The hero now reads Conoce tu salud, with salud in the existing AnalogType treatment. Preserve the runner and scene transitions. Do not use Impeccable or introduce stock imagery. Previous source versions remain recoverable.

The 03.28 refinement makes Conoce tu a smaller regular-weight introduction, loosens its tracking and brings salud closer. Menu lettering uses a finer, coverage-weighted dot grid so counters, accents and edges remain recognizable.
