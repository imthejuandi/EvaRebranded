# Hero typography — 03.28

Conoce tu introduces the phrase at a quieter scale; the analog salud remains its visual emphasis. Both use regular weight 400. Size and texture create hierarchy without adding a competing bold weight.

The lead-in is 120px at a 1440px viewport (8.333vw, capped at 160px); it is 56.55px at 390px (14.5vw). Tracking is -0.035em instead of -0.075em, with 1.06 line-height. This restores space between letterforms and reduces the density of the longer phrase.

The dotted word is 720px wide at 1440px, with a 960px cap, and 84vw on mobile. Its top moves to 44% of the desktop stage / 43% on mobile. The introduction sits at 22%. Bringing them closer makes them read as one phrase while the runner remains between the two visual anchors.

The poster and reduced-motion heading use the same scale, weight and tracking, with an explicit gap before the analog word. The original scroll exit directions, official logo, images, and business content are preserved.
