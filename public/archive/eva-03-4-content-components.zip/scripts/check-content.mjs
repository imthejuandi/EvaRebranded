import {readFile,stat} from 'node:fs/promises';
import assert from 'node:assert/strict';
const html=await readFile('dist/client/index.html','utf8');
const expected=[
 ['comparison context','una-perspectiva'],['annual cadence','puntos de información al año'],
 ['five specimen section','biomarcadores'],['full method','el-metodo'],['age explanation','tu-evolucion'],
 ['full founder quote','cuando comencé mi propio camino de salud preventiva'],['quarterly price','al trimestre'],
 ['expanded panel','165+'],['cancellation','Cancela cuando quieras'],['free upload','Sin tarjeta de crédito'],
 ['collection location','Recogida de muestra en casa'],['laboratory','Análisis en laboratorio acreditado'],
 ['biological age qualification','Ejemplo ilustrativo, no una predicción de tu resultado'],['distinct score','puntuación de longevidad'],
];
for(const [label,value] of expected)assert(html.includes(value),`Missing imported information: ${label}`);
for(const [marker,value,range] of [['Vitamina D','28','50–80'],['hs-CRP','2.1','0–1'],['Insulina en ayunas','11','2–5'],['ApoB','98','0–60'],['Ferritina','320','50–150']]){
 assert(html.includes(marker)&&html.includes(`data-dot-number="${value}"`)&&html.includes(range),`Missing specimen: ${marker}`);
}
assert.equal((html.match(/class="marker-card"/g)||[]).length,5);
for(const route of ['signup','upload','how-it-works','science','pricing','about','legal/privacy','legal/terms','legal/cookies','blog'])assert(html.includes(`https://www.evahealth.es/es/${route}`),`Missing business destination: ${route}`);
assert(html.includes('mailto:hello@evahealth.es')&&html.includes('https://www.evahealth.es/en'));
assert(!html.includes('95%')&&!html.includes('1.1T'),'Unverified statistics must stay in the review notes');
assert(!html.includes('Acción requerida')&&!html.includes('Por debajo del óptimo'),'Do not import misleading specimen directions');
const history=await readFile('dist/client/history.html','utf8');assert(history.includes('/archive/eva-03-3-movement.zip'));
assert((await stat('dist/client/archive/eva-03-3-movement.zip')).size>1000000);
assert((await stat('dist/client/review/content-import.md')).size>1000);
console.log('Content import passed: all source sections, five numerical specimens, 12 business destinations, qualified examples, review exceptions and prior source archive.');
