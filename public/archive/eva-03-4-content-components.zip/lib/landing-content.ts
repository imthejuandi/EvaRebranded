// Transcribed from https://www.evahealth.es/es, reviewed 2026-09-10.
// These are public illustrative specimens, not personal health records or new clinical thresholds.
export const specimens=[
 {name:'Vitamina D',detail:'25-OH',value:'28',unit:'ng/mL',standard:[20,100],eva:[50,80]},
 {name:'hs-CRP',detail:'Proteína C reactiva ultrasensible',value:'2.1',unit:'mg/L',standard:[0,3],eva:[0,1]},
 {name:'Insulina en ayunas',detail:'Insulina basal',value:'11',unit:'µIU/mL',standard:[2,19],eva:[2,5]},
 {name:'ApoB',detail:'Apolipoproteína B',value:'98',unit:'mg/dL',standard:[0,130],eva:[0,60]},
 {name:'Ferritina',detail:'Ferritina sérica',value:'320',unit:'ng/mL',standard:[30,400],eva:[50,150]},
] as const;

export const businessLinks={
 signup:'https://www.evahealth.es/es/signup',upload:'https://www.evahealth.es/es/upload',
 method:'https://www.evahealth.es/es/how-it-works',science:'https://www.evahealth.es/es/science',
 pricing:'https://www.evahealth.es/es/pricing',about:'https://www.evahealth.es/es/about',
 privacy:'https://www.evahealth.es/es/legal/privacy',terms:'https://www.evahealth.es/es/legal/terms',
 cookies:'https://www.evahealth.es/es/legal/cookies',blog:'https://www.evahealth.es/es/blog',
 english:'https://www.evahealth.es/en',email:'mailto:hello@evahealth.es',
};

export const methodSteps=[
 {title:'Recoge tu muestra, en casa.',copy:'Con Tasso+, sin desplazarte a una clínica ni pedir cita. Recogida de muestra en casa, análisis en laboratorio acreditado.'},
 {title:'Construye tu base de longevidad.',copy:'15 biomarcadores cada 3 meses. ApoB, hs-CRP e insulina en ayunas, entre otros. Al repetirlos, una lectura se convierte en una trayectoria.'},
 {title:'Pon tus resultados en contexto.',copy:'Una lectura frente a los rangos de longevidad de EVA, junto con una estimación de tu edad biológica y tu puntuación de longevidad.'},
 {title:'Elige tu siguiente paso.',copy:'Sigue lo que estás mejorando, explora otro panel o reserva una extracción para el panel completo de 165+ marcadores. Cada 90 días, vuelve a conocerte.'},
];
