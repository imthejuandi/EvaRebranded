'use client';
import {useEffect,useRef,useState} from 'react';
import {specimens} from '@/lib/landing-content';
import {DotNumber} from './DotNumber';

export function BiomarkerGallery({calm=false}:{calm?:boolean}){
 const track=useRef<HTMLDivElement>(null);const [current,setCurrent]=useState(0);
 useEffect(()=>{const el=track.current;if(!el)return;let raf=0;const update=()=>{cancelAnimationFrame(raf);raf=requestAnimationFrame(()=>{const box=el.getBoundingClientRect();let nearest=0,distance=Infinity;Array.from(el.children).forEach((child,i)=>{const d=Math.abs(child.getBoundingClientRect().left-box.left);if(d<distance){distance=d;nearest=i}});setCurrent(nearest)});};el.addEventListener('scroll',update,{passive:true});return()=>{el.removeEventListener('scroll',update);cancelAnimationFrame(raf)}},[]);
 const go=(index:number)=>{const el=track.current,child=el?.children[index] as HTMLElement|undefined;if(!el||!child)return;const left=child.getBoundingClientRect().left-el.getBoundingClientRect().left+el.scrollLeft-parseFloat(getComputedStyle(el).paddingLeft);el.scrollTo({left,behavior:calm||matchMedia('(prefers-reduced-motion: reduce)').matches?'instant':'smooth'});};
 return <section id="biomarcadores" className="marker-section" aria-labelledby="markers-title">
  <div className="section-kicker"><span>02 / LO QUE CUENTAN TUS DATOS</span><span>UNA LECTURA CON CONTEXTO</span></div>
  <div className="marker-intro"><h2 id="markers-title">El mismo dato.<br/><em>Otra perspectiva.</em></h2><p>Un resultado se entiende mejor cuando sabes cómo leerlo. Estos cinco ejemplos muestran la diferencia entre el intervalo de referencia y el rango de longevidad que presenta EVA.</p></div>
  <div className="marker-tools"><p aria-live="polite">{String(current+1).padStart(2,'0')} <span>/ 05 · {specimens[current].name}</span></p><div><button aria-label="Biomarcador anterior" disabled={current===0} onClick={()=>go(current-1)}>←</button><button aria-label="Siguiente biomarcador" disabled={current===specimens.length-1} onClick={()=>go(current+1)}>→</button></div></div>
  <div className="marker-track" ref={track} tabIndex={0} role="region" aria-label="Cinco ejemplos de biomarcadores. Desliza o usa las flechas." onKeyDown={e=>{if(e.key==='ArrowRight'){e.preventDefault();go(Math.min(4,current+1))}if(e.key==='ArrowLeft'){e.preventDefault();go(Math.max(0,current-1))}}}>
   {specimens.map((item,i)=>{const max=Math.max(item.standard[1],item.eva[1],Number(item.value))*1.1;return <article key={item.name} className="marker-card" aria-labelledby={'marker-'+i}>
    <div className="marker-caption"><span>LECTURA 0{i+1}</span><span>{item.detail}</span></div><h3 id={'marker-'+i}>{item.name}</h3>
    <div className="marker-reading"><DotNumber value={item.value} calm={calm} active={current===i}/><span>{item.unit}</span></div>
    <div className="range-comparison">{[{label:'Intervalo de referencia',range:item.standard,className:'standard'},{label:'Rango de longevidad EVA',range:item.eva,className:'longevity'}].map(row=><div className={'range-row '+row.className} key={row.label}><p>{row.label}<span>{row.range.join('–')} <small>{item.unit}</small></span></p><div className="range-line" aria-hidden="true"><i style={{left:row.range[0]/max*100+'%',width:(row.range[1]-row.range[0])/max*100+'%'}}/><b style={{left:Number(item.value)/max*100+'%'}}/></div></div>)}</div>
   </article>})}
  </div>
  <p className="illustration-note">Ejemplos ilustrativos. Los intervalos mostrados no son una recomendación individual; su interpretación depende del contexto de cada persona.</p>
 </section>;
}
