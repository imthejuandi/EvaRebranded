'use client';
import {useEffect,useRef,useState,type CSSProperties} from 'react';

type Cell={x:number;y:number;value:number;seed:number};
/** A serif silhouette sampled into luminous character cells. No independent clock. */
export function AnalogType({text,width,height,frame=0,color='#f3f0e8',style}: {text:string;width:number;height:number;frame?:number;color?:string;style?:CSSProperties}){
 const canvas=useRef<HTMLCanvasElement>(null),cells=useRef<Cell[]>([]);
 const [ready,setReady]=useState(false);
 const step=Math.max(2.6,width/104);
 useEffect(()=>{
  const mask=document.createElement('canvas');mask.width=Math.ceil(width);mask.height=Math.ceil(height);
  const ctx=mask.getContext('2d',{willReadFrequently:true});if(!ctx)return;
  let size=height*1.18;ctx.font=`${size}px "Times New Roman", Georgia, serif`;
  size*=Math.min(1,(width-step*2)/ctx.measureText(text).width);
  ctx.font=`${size}px "Times New Roman", Georgia, serif`;ctx.fillStyle='white';ctx.textBaseline='alphabetic';
  const metrics=ctx.measureText(text),actualHeight=metrics.actualBoundingBoxAscent+metrics.actualBoundingBoxDescent;
  ctx.fillText(text,(width-metrics.width)/2,(height-actualHeight)/2+metrics.actualBoundingBoxAscent);
  const data=ctx.getImageData(0,0,mask.width,mask.height).data,next:Cell[]=[];
  for(let y=0,row=0;y<height-step;y+=step,row++)for(let x=0,col=0;x<width-step;x+=step,col++){
   let coverage=0;for(const dy of [.25,.5,.75])for(const dx of [.25,.5,.75])coverage+=data[(Math.floor(y+step*dy)*mask.width+Math.floor(x+step*dx))*4+3]/255;
   if(coverage>1.5)next.push({x,y,value:Math.min(1,coverage/4),seed:(col*37+row*71)%101});
  }
  cells.current=next;setReady(true);
 },[text,width,height,step]);
 useEffect(()=>{
  const el=canvas.current;if(!el)return;const ctx=el.getContext('2d');if(!ctx)return;
  const dpr=Math.min(window.devicePixelRatio||1,2),pixelWidth=Math.ceil(width*dpr),pixelHeight=Math.ceil(height*dpr);
  if(el.width!==pixelWidth||el.height!==pixelHeight){el.width=pixelWidth;el.height=pixelHeight}
  ctx.setTransform(dpr,0,0,dpr,0,0);ctx.clearRect(0,0,width,height);
  const scan=(frame*2.6)%(width+80)-40,alphabet='EVAVIDASALUD';
  for(const cell of cells.current){
   const glow=Math.max(0,1-Math.abs(cell.x-scan)/45);
   ctx.globalAlpha=(.83+glow*.17)*cell.value;ctx.fillStyle=color;
   ctx.fillRect(cell.x,cell.y,step*.87,step*.87);
   if(cell.seed%4!==0){ctx.globalAlpha=.30+glow*.16;ctx.fillStyle='#0b1010';ctx.font=`${step*.78}px Arial`;ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText(alphabet[(cell.seed+Math.floor(frame/9))%alphabet.length],cell.x+step*.43,cell.y+step*.47)}
  }
 },[frame,width,height,step,color,ready,text]);
 return <span data-analog-type={text} data-analog-frame={frame} data-cell-count={ready?cells.current.length:0} aria-hidden="true" style={{display:'block',position:'relative',width,height,...style}}>
  {!ready&&<svg viewBox={`0 0 ${width} ${height}`} width="100%" height="100%"><text x="50%" y="75%" textAnchor="middle" textLength={width*.94} lengthAdjust="spacingAndGlyphs" fill={color} fontFamily="Times New Roman, Georgia, serif" fontSize={height}>{text}</text></svg>}
  <canvas ref={canvas} style={{position:'absolute',inset:0,width:'100%',height:'100%',opacity:ready?1:0}}/>
 </span>
}
