import type {Metadata} from 'next';
import './globals.css';
export const metadata:Metadata={title:'EVA — Más vida.',description:'15 biomarcadores cada 3 meses. Recogida de muestra en casa, análisis en laboratorio acreditado y resultados con contexto. EVA: salud preventiva, a tu ritmo.'};
export default function Layout({children}:{children:React.ReactNode}){return <html lang="es"><body>{children}</body></html>}
