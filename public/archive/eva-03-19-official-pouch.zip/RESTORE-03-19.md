# Restore EVA03.19

Extract the03.12source package, then apply the03.18overlay followed by this03.19overlay. Apply deletions from RESTORE-03-19.json. Keep the separate public/archive downloads if building the History links. Includes the original finite pouch video, original stills and exact component sources.
