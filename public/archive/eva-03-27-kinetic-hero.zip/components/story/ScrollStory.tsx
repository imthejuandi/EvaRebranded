'use client';
import {EvaWordmark} from '@/components/story/EvaWordmark';
import {AnalogType} from './AnalogType';
import {Arrow} from './Arrow';
import {Player,type PlayerRef} from '@remotion/player';
import {memo,useEffect,useMemo,useRef,useState} from 'react';
import {EvaFilm,DURATION} from './EvaFilm';
import {HealthEditorial} from './HealthEditorial';
import {BusinessOffer} from './BusinessOffer';
import {BusinessNavigation} from './BusinessNavigation';
import {DotMorphLabel} from './DotMorphLabel';
import {BusinessFooter} from './BusinessFooter';
import {businessLinks} from '@/lib/landing-content';
import {glowRunner} from '@/lib/design';
import {SignalPassage} from './SignalPassage';
import {storyMotion} from '@/lib/story-motion';
const EditorialContent=memo(HealthEditorial),OfferContent=memo(BusinessOffer),SignalContent=memo(SignalPassage);
export function ScrollStory(){
 const section=useRef<HTMLElement>(null),stage=useRef<HTMLDivElement>(null),player=useRef<PlayerRef>(null);
 const [size,setSize]=useState<{width:number;height:number}|null>(null);const [frame,setFrame]=useState(0);const [calm,setCalm]=useState(false);const [runnerPaused,setRunnerPaused]=useState(false);
 const filmProps=useMemo(()=>({ambientRunner:!runnerPaused,onRunnerBlocked:()=>setRunnerPaused(true)}),[runnerPaused]);
 useEffect(()=>{const mq=matchMedia('(prefers-reduced-motion: reduce)');setCalm(mq.matches);const change=()=>setCalm(mq.matches);mq.addEventListener('change',change);return()=>mq.removeEventListener('change',change)},[]);
 useEffect(()=>{if(calm||!stage.current)return;const el=stage.current;const measure=()=>setSize({width:Math.round(el.clientWidth),height:Math.round(el.clientHeight)});const ro=new ResizeObserver(measure);ro.observe(el);measure();return()=>ro.disconnect()},[calm]);
 useEffect(()=>{if(calm||!size||!player.current)return;let raf=0,last=-1;const update=()=>{raf=0;if(document.visibilityState!=='visible'||!section.current||!stage.current)return;const box=section.current.getBoundingClientRect();const p=Math.max(0,Math.min(1,-box.top/(box.height-stage.current.clientHeight)));const f=p*(DURATION-1);if(f!==last){player.current?.seekTo(f);setFrame(previous=>{
 const key=(n:number)=>{const m=storyMotion(n),h=size.height,small=size.width<=700;return [m.lightAt(50/h),m.lightAt(1-(small?45:50)/h),m.lightAt(1-((small?75:41)+(n<200?22:5))/h),n<200,n<30,n<230?0:n<490?1:n<715?2:3].join('/')};
 return key(previous)===key(f)?previous:f;
 });last=f}};const schedule=()=>{if(!raf)raf=requestAnimationFrame(update)};window.addEventListener('scroll',schedule,{passive:true});window.addEventListener('resize',schedule);document.addEventListener('visibilitychange',schedule);schedule();return()=>{window.removeEventListener('scroll',schedule);window.removeEventListener('resize',schedule);document.removeEventListener('visibilitychange',schedule);cancelAnimationFrame(raf)}},[size,calm]);
 const jump=(f:number)=>{if(!section.current||!stage.current)return;window.scrollTo({top:section.current.offsetTop+(section.current.offsetHeight-stage.current.clientHeight)*f/(DURATION-1),behavior:'instant'})};
 const motion=storyMotion(frame),height=size?.height??900;
 const mobile=(size?.width??1440)<=700;
 const headerLight=motion.lightAt(50/height),navLight=motion.lightAt(1-(mobile?45:50)/height),noteLight=motion.lightAt(1-((mobile?75:41)+(frame<200?22:5))/height);
 const chapter=frame<230?0:frame<490?1:frame<715?2:3;
 useEffect(()=>{const ctx=(document as Document&{modelContext?:{registerTool:(tool:unknown,opts:unknown)=>unknown}}).modelContext;if(!ctx)return;const lifecycle=new AbortController();const register=(tool:unknown)=>{try{Promise.resolve(ctx.registerTool(tool,{signal:lifecycle.signal})).catch(()=>{})}catch{}};register({name:'read_eva_story',description:'Read the current EVA chapter, native scroll position and rendered Remotion frame.',inputSchema:{type:'object',properties:{},additionalProperties:false},annotations:{readOnlyHint:true},execute:()=>({frame:Number(document.querySelector('[data-rendered-frame]')?.getAttribute('data-rendered-frame')??0),scrollY:window.scrollY,reducedMotion:!document.querySelector('.scroll-journey')})});register({name:'navigate_eva_chapter',description:'Navigate using the same four chapter controls visible below the EVA motion story.',inputSchema:{type:'object',properties:{chapter:{type:'integer',minimum:1,maximum:4}},required:['chapter'],additionalProperties:false},annotations:{readOnlyHint:false},execute:async(input:{chapter:number})=>{if(!Number.isInteger(input.chapter)||input.chapter<1||input.chapter>4)throw new Error('Chapter must be an integer from 1 to 4.');if(!section.current||!stage.current)throw new Error('Motion is reduced. Use the visible narrative.');jump([0,325,560,810][input.chapter-1]);await new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve)));return{chapter:input.chapter,frame:Number(document.querySelector('[data-rendered-frame]')?.getAttribute('data-rendered-frame'))}}});return()=>lifecycle.abort()},[calm]);
 return <main><a className="skip" href="#empezar">Ver planes y empezar</a><header className={'masthead '+(headerLight&&!calm?'ink':'')}><EvaWordmark/><div className="header-actions"><a className="header-language" href={businessLinks.english} lang="en" aria-label="EVA Health in English"><DotMorphLabel>EN</DotMorphLabel></a><a className="join" href={businessLinks.signup} aria-label="Empieza con EVA">Empieza </a><BusinessNavigation/></div></header>
 {!calm?<section className="scroll-journey" ref={section} aria-label="La experiencia EVA"><div className="stage" ref={stage}><div aria-hidden="true" className="film">{size?<Player ref={player} component={EvaFilm} inputProps={filmProps} compositionWidth={size.width} compositionHeight={size.height} durationInFrames={DURATION} fps={30} autoPlay={false} loop={false} controls={false} clickToPlay={false} doubleClickToFullscreen={false} spaceKeyToPlayOrPause={false} allowFullscreen={false} moveToBeginningWhenEnded={false} initiallyMuted browserMediaControlsBehavior={{mode:'prevent-media-session'}} style={{width:'100%',height:'100%',pointerEvents:'none'}}/>:<div className="poster"><img src={glowRunner.poster} alt="" fetchPriority="high" decoding="async"/><div className="poster-title">Conoce tu<AnalogType text="salud." width={640} height={260} style={{width:'100%',height:'auto',aspectRatio:'64 / 26'}}/></div></div>}</div><nav aria-label="Capítulos de la experiencia" className={'chapter-nav '+(navLight?'ink':'')}>{['Vivir','Conocer','Entender','Seguir'].map((n,i)=><button key={n} onClick={()=>jump([0,325,560,810][i])} aria-current={chapter===i?'step':undefined}><small>0{i+1}</small><span>{n}</span><i style={{scale:`${chapter===i?1:.12} 1`}}/></button>)}</nav><div className={'stage-note '+(noteLight?'ink':'')}>{frame<200&&<button className="runner-pause" aria-pressed={runnerPaused} onClick={()=>setRunnerPaused(!runnerPaused)}>{runnerPaused?'Reanudar imagen':'Pausar imagen'}</button>}<span className="scroll-cue">{frame<30?'DESLIZA PARA DESCUBRIR':'TU VIDA · A TU RITMO'} <Arrow direction="down"/></span></div></div><div className="sr-only"><h1>Conoce tu salud. Salud preventiva a tu ritmo.</h1><p>Recogida de muestra en casa, análisis en laboratorio acreditado. 15 biomarcadores cada 90 días para entender tus resultados y seguir tu evolución.</p></div></section>:<section className="calm-hero"><img src={glowRunner.poster} alt="Figura corriendo, reinterpretada en luz ámbar y azul"/><h1 aria-label="Conoce tu salud.">Conoce tu<AnalogType text="salud." width={640} height={260} style={{width:'100%',height:'auto',aspectRatio:'64 / 26'}}/></h1><p>Salud preventiva.<br/>Para vivir a tu ritmo.</p></section>}
 <SignalContent calm={calm}/>
 <EditorialContent calm={calm}/>
 <OfferContent/>
 <BusinessFooter calm={calm} onCalmChange={v=>{setCalm(v);window.scrollTo({top:0,behavior:'instant'})}}/>
 </main>
}
