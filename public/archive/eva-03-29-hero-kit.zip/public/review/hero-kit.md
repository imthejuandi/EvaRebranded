# Hero Kit CTA — 03.29

A paper-colored rectangular link replaces the former Salud preventiva / Para vivir a tu ritmo paragraph in the lower-left hero. The primary text is Desbloquea tu salud, weight 600; pide tu primer kit and 99€ por Kit use weight 400 and smaller text. The whole surface links to the existing https://www.evahealth.es/es/signup destination.

The link is independent of the decorative, aria-hidden Remotion film. It stays available during the initial reading interval, then uses the existing scroll update to fade between frames 20–90. Once invisible, it is hidden and inert; reversing the scroll restores it. No additional animation loop or image payload is introduced.

Desktop: 370px wide, 90px minimum height, lower-left gutter, 22px primary / 13px secondary / 12px price. Mobile: full content width with 24px side gutters, 84px minimum height, 20px primary. At 360px and below, primary text is 18px. Keyboard focus uses a visible amber outline. Hover shifts only the arrow by 3px; reduced-motion preference removes these CSS transitions.

The reduced-motion hero keeps a static link. The system page exposes the same reusable component. Desktop and mobile layouts were visually reviewed locally, including a 320×568 viewport and actual navigation to EVA signup; no form was submitted.
