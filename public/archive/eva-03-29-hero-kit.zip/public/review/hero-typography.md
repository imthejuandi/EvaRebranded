# Hero typography — 03.29

The heading frames the runner diagonally. Conoce tu sits in the upper left, at 15% of the desktop stage and 16% on mobile. Regular weight 400, -0.035em tracking and 1.06 line-height keep the longer introduction open.

The introduction measures 106.56px at 1440px (7.4vw, capped at 124px), and 48.75px at 390px (12.5vw). The analog salud is 518.4px wide at 1440px (36vw, capped at 640px) and 241.8px at 390px (62vw). It sits lower right at 60% of the desktop stage; on mobile it starts at 58% with a bottom-clearance cap to stay above the CTA on short screens.

The poster and reduced-motion hero share the same placement and scale. The runner, original exit directions, approved cell effect and official logo are unchanged. The superseded 03.28 composition is available in the history archive.
