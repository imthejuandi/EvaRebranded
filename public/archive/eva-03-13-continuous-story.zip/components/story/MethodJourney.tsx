'use client';

import {useMemo, useRef, useState, type KeyboardEvent} from 'react';
import {businessLinks, methodSteps} from '@/lib/landing-content';
import {glowRunner, solarLifestyle} from '@/lib/design';
import {halftoneState, HALFTONE_VIEWBOX} from '@/lib/halftone-motion';
import {DotNumber} from './DotNumber';

// Source-led Glow Motion imagery; exact existing halftone endpoint geometry.
// SAVEE references viewed: _a3PZvq, Yb1CVRQ, YC6VZQI and xMeroxU.
// No video, canvas, frame loop, observer, runtime blur, or unrequested imagery.
const chapters = ['En casa', 'Resultados', 'Contexto', 'Evolución'];
const captions = [
  ['TASSO+', 'RECOGIDA EN CASA'],
  ['15 BIOMARCADORES', 'TU PUNTO DE PARTIDA'],
  ['TU LECTURA', 'EN PERSPECTIVA'],
  ['CADA 90 DÍAS', 'COMPARA TUS LECTURAS'],
];

function JourneyArrow({back = false}: {back?: boolean}) {
  return <svg viewBox="0 0 24 24" width="24" height="24" fill="none" aria-hidden="true" focusable="false" style={back ? {transform: 'rotate(180deg)'} : undefined}><path d="M4 12h15m-6-6 6 6-6 6" stroke="currentColor" strokeWidth="1.35"/></svg>;
}

function MethodReadout({value}: {value: '15' | '90' | 'TÚ'}) {
  const groups = useMemo(() => {
    const paths = Array.from({length: 8}, () => '');
    const frame = value === '15' ? 0 : value === '90' ? 180 : 360;
    const round = (number: number) => Number(number.toFixed(4));
    halftoneState(frame).points.forEach(({x, y, r}, index) => {
      if (r <= 0) return;
      const radius = round(r), diameter = round(r * 2);
      paths[index * 7 % 8] += `M${round(x - r)},${round(y)}a${radius},${radius} 0 1,0 ${diameter},0a${radius},${radius} 0 1,0 ${-diameter},0`;
    });
    return paths;
  }, [value]);
  return <svg className="method-readout" viewBox={HALFTONE_VIEWBOX} aria-hidden="true" focusable="false" data-method-readout={value}>
    {groups.map((path, index) => <path key={index} d={path} fill="currentColor" style={{animationDelay: `${index * 35}ms`}}/>)}
  </svg>;
}

function MethodArtwork({step}: {step: number}) {
  if (step === 0) return <div className="method-product-art">
    <img className="method-glow-product" src="/art/tasso-plus-glow-v1.webp" alt="Tasso+ en luz suave coral y lila" loading="lazy" decoding="async" width="1000" height="1000"/>
    <div className="method-in-use">
      <img src="/art/tasso-plus-in-use-600.webp" alt="Tasso+ colocado en la parte superior del brazo" loading="lazy" decoding="async" width="1220" height="1566"/>
    </div>
  </div>;

  const photo = step === 1
    ? {src: glowRunner.poster, srcSet: undefined, alt: glowRunner.alt}
    : step === 2
      ? {src: '/art/stretch.jpg', srcSet: undefined, alt: 'Una persona estirándose, entre luz cálida y reflejos lilas'}
      : {src: solarLifestyle.poster, srcSet: solarLifestyle.posterSrcSet, alt: solarLifestyle.alt};
  const value = step === 1 ? '15' : step === 2 ? 'TÚ' : '90';
  return <div className={`method-photo-art method-photo-art-${step}`}>
    <img src={photo.src} srcSet={photo.srcSet} sizes="(max-width: 700px) calc(100vw - 48px), 50vw" alt={photo.alt} loading="lazy" decoding="async" width="1450" height="1800"/>
    <div className="method-photo-shade" aria-hidden="true"/>
    <div className="method-photo-reading" aria-hidden="true">
      <MethodReadout value={value}/>
      <span>{step === 1 ? 'BIOMARCADORES' : step === 2 ? 'EN PERSPECTIVA' : 'DÍAS. UNA NUEVA LECTURA.'}</span>
    </div>
  </div>;
}

export function MethodJourney({calm = false}: {calm?: boolean}) {
  const [active, setActive] = useState(0);
  const [hasChanged, setHasChanged] = useState(false);
  const tabs = useRef<Array<HTMLButtonElement | null>>([]);

  function selectStep(index: number, focus = false) {
    const next = Math.max(0, Math.min(methodSteps.length - 1, index));
    if (next !== active) { setHasChanged(true); setActive(next); }
    if (focus) tabs.current[next]?.focus();
  }

  function handleKey(event: KeyboardEvent<HTMLButtonElement>, index: number) {
    let next: number;
    if (event.key === 'ArrowRight') next = (index + 1) % methodSteps.length;
    else if (event.key === 'ArrowLeft') next = (index + methodSteps.length - 1) % methodSteps.length;
    else if (event.key === 'Home') next = 0;
    else if (event.key === 'End') next = methodSteps.length - 1;
    else return;
    event.preventDefault();
    selectStep(next, true);
  }

  return <section className={'method-journey' + (calm ? ' method-journey-calm' : '') + (hasChanged ? ' method-has-changed' : '')} id="el-metodo" aria-labelledby="routine-title">
    <div className="section-kicker"><span>02 / EL MÉTODO</span><span>UN MOMENTO PARA TI.</span></div>
    <div className="method-heading">
      <h2 id="routine-title">Cuatro pasos.<br/><em>A tu ritmo.</em></h2>
      <p>Recogida de muestra en casa, análisis en laboratorio acreditado. De tu primera muestra al seguimiento cada 90 días.</p>
    </div>

    <div className="method-chapters" role="tablist" aria-label="Los cuatro pasos de EVA" aria-orientation="horizontal">
      {methodSteps.map((step, index) => <button
        key={index}
        ref={node => { tabs.current[index] = node; }}
        id={`method-tab-${index}`}
        role="tab"
        type="button"
        aria-selected={active === index}
        aria-controls={`method-panel-${index}`}
        aria-label={`Paso ${index + 1}, ${chapters[index]}: ${step.title}`}
        tabIndex={active === index ? 0 : -1}
        onClick={() => selectStep(index)}
        onKeyDown={event => handleKey(event, index)}
      ><span className="method-chapter-index">0{index + 1}</span><span>{chapters[index]}</span><i aria-hidden="true"/></button>)}
    </div>

    {methodSteps.map((step, index) => <div
      key={index}
      className="method-panel"
      id={`method-panel-${index}`}
      role="tabpanel"
      aria-labelledby={`method-tab-${index}`}
      hidden={active !== index}
      tabIndex={0}
    >
      <figure className={`method-figure method-figure-${index}`}>
        <div className="method-figure-stage">{active === index && <MethodArtwork step={index}/>}</div>
        <figcaption><span>{captions[index][0]}</span><span>{captions[index][1]}</span></figcaption>
      </figure>
      <div className="method-chapter-copy">
        <div className="method-page-number" aria-hidden="true"><DotNumber value={`0${index + 1}`} density="coarse" calm/><span>/ 04</span></div>
        <div className="method-chapter-body"><h3>{step.title}</h3><p>{step.copy}</p></div>
        <div className="method-paging" role="group" aria-label="Recorrer los pasos">
          <button type="button" aria-label="Paso anterior" disabled={index === 0} onClick={() => selectStep(index - 1, true)}><JourneyArrow back/><span>Anterior</span></button>
          <button type="button" aria-label="Siguiente paso" disabled={index === methodSteps.length - 1} onClick={() => selectStep(index + 1, true)}><span>Siguiente</span><JourneyArrow/></button>
        </div>
        <a className="method-detail-link" href={businessLinks.method}>Así funciona EVA <JourneyArrow/></a>
      </div>
    </div>)}
  </section>;
}
