'use client';
import {Player,type PlayerRef} from '@remotion/player';
import {useEffect,useRef,useState} from 'react';
import type {BodySignalFilm} from './BodySignalFilm';
import {HalftoneNumber} from './HalftoneNumber';
import {BODY_SIGNAL_DURATION as SIGNAL_DURATION,bodySignalLabels as signalLabels,bodySignalStops as signalStops,bodySignalChapter} from '@/lib/body-signal';
export function SignalPassage({calm=false}:{calm?:boolean}){
 const section=useRef<HTMLElement>(null),stage=useRef<HTMLDivElement>(null),player=useRef<PlayerRef>(null);
 const [size,setSize]=useState<{width:number;height:number}|null>(null),[chapter,setChapter]=useState(0),[Film,setFilm]=useState<typeof BodySignalFilm|null>(null);
 useEffect(()=>{if(calm||!stage.current)return;const el=stage.current;const measure=()=>setSize({width:Math.round(el.clientWidth),height:Math.round(el.clientHeight)});const ro=new ResizeObserver(measure);ro.observe(el);measure();return()=>ro.disconnect()},[calm]);
 useEffect(()=>{
  if(calm||!section.current)return;let alive=true;
  const observer=new IntersectionObserver(entries=>{if(entries[0]?.isIntersecting){observer.disconnect();void import('./BodySignalFilm').then(module=>{if(alive)setFilm(()=>module.BodySignalFilm)}).catch(()=>{})}},{rootMargin:'150% 0px'});
  observer.observe(section.current);return()=>{alive=false;observer.disconnect()};
 },[calm]);
 useEffect(()=>{
  if(calm||!size||!Film)return;let raf=0,last=-1;
  const update=()=>{
   raf=0;if(document.visibilityState!=='visible'||!section.current||!stage.current)return;
   const box=section.current.getBoundingClientRect();if(box.top>=window.innerHeight||box.bottom<=0)return;
   const f=Math.max(0,Math.min(1,-box.top/(box.height-stage.current.clientHeight)))*(SIGNAL_DURATION-1);
   if(f!==last){player.current?.seekTo(f);setChapter(bodySignalChapter(f));last=f}
  };
  const schedule=()=>{if(!raf)raf=requestAnimationFrame(update)};
  window.addEventListener('scroll',schedule,{passive:true});window.addEventListener('resize',schedule);document.addEventListener('visibilitychange',schedule);schedule();
  return()=>{window.removeEventListener('scroll',schedule);window.removeEventListener('resize',schedule);document.removeEventListener('visibilitychange',schedule);cancelAnimationFrame(raf)};
 },[calm,size,Film]);
 const jump=(f:number)=>{if(section.current&&stage.current)window.scrollTo({top:section.current.offsetTop+(section.current.offsetHeight-stage.current.clientHeight)*f/(SIGNAL_DURATION-1),behavior:'instant'})};
 if(calm)return <section id="una-senal" className="signal-calm body-signal-calm"><p className="eyebrow">UNA SEÑAL PARA CONOCERTE</p><h2>Entiende mejor las señales<br/><em>de tu cuerpo.</em></h2><HalftoneNumber/><p>15 biomarcadores. Cada 90 días.<br/>De los datos. A tu vida.</p></section>;
 return <section id="una-senal" className={'signal-passage body-signal-passage '+(!size||!Film?'signal-loading':'')} ref={section} aria-labelledby="signal-title"><div className="signal-stage" ref={stage}><div aria-hidden="true" className="film">{size&&Film?<Player ref={player} component={Film} compositionWidth={size.width} compositionHeight={size.height} durationInFrames={SIGNAL_DURATION} fps={30} controls={false} autoPlay={false} clickToPlay={false} spaceKeyToPlayOrPause={false} doubleClickToFullscreen={false} allowFullscreen={false} style={{width:'100%',height:'100%',pointerEvents:'none'}}/>:<div className="signal-placeholder"><p>UNA SEÑAL PARA CONOCERTE</p><h2>De los datos.<br/><em>A tu vida.</em></h2><p>15 biomarcadores. Cada 90 días.<br/>Compara tus resultados en el tiempo.</p></div>}</div><nav className="signal-controls" aria-label="Señales de EVA">{signalLabels.map((label,i)=><button key={label} aria-current={chapter===i?'step':undefined} onClick={()=>jump(signalStops[i])}><span>0{i+1}</span>{label}</button>)}</nav></div><div className="sr-only"><h2 id="signal-title">Entiende mejor las señales de tu cuerpo. De los datos. A tu vida.</h2><p>15 biomarcadores. Cada 90 días. Compara tus resultados en el tiempo.</p></div></section>
}
