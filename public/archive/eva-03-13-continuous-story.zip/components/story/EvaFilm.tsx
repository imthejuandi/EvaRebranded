import {AbsoluteFill,Img,staticFile,interpolate,useCurrentFrame,useVideoConfig,useRemotionEnvironment} from 'remotion';
import {useEffect,useRef,useState} from 'react';
import {GlowMotion} from './GlowMotion';
import {glowRunner} from '@/lib/design';
import {AnalogType} from './AnalogType';
import {storyMotion} from '@/lib/story-motion';
import {productHover} from '@/lib/product-motion';
export const DURATION=981;
const clamp={extrapolateLeft:'clamp',extrapolateRight:'clamp'} as const;
const range=(f:number,a:number,b:number,x:number,y:number)=>interpolate(f,[a,b],[x,y],clamp);
export function EvaFilm({ambientRunner=true,onRunnerBlocked}:{ambientRunner?:boolean;onRunnerBlocked?:()=>void}={}){
 const f=useCurrentFrame();const {width:w,height:h}=useVideoConfig();const environment=useRemotionEnvironment();const still=environment.isRendering||environment.isStudio;const mobile=w<700;const pad=mobile?24:48;
 const travel=range(f,45,190,0,1);const runnerX=travel*w*1.05;const motion=storyMotion(f);
 const scene=f<230?'Vivir':f<490?'Conocer':f<715?'Entender':'Seguir';
 const track=useRef<HTMLDivElement>(null);const [overflow,setOverflow]=useState(w);useEffect(()=>{const el=track.current;if(!el)return;const measure=()=>setOverflow(Math.max(0,el.scrollWidth-(w-pad*2)));measure();const ro=new ResizeObserver(measure);ro.observe(el);return()=>ro.disconnect()},[w,pad]);
 const hover=productHover(f);
 return <AbsoluteFill data-rendered-frame={f} data-scene={scene} style={{background:'#0b1010',color:'#f3f0e8',fontFamily:'Arial, Helvetica, sans-serif',overflow:'hidden'}}>
  <AbsoluteFill data-layer="human" style={{overflow:'hidden',translate:`0 ${motion.humanY*h}px`,visibility:Math.abs(motion.humanY)>=1?'hidden':'visible',willChange:Math.abs(motion.humanY)<1?'translate':'auto'}}>
   <div data-layer="runner-plane" style={{position:'absolute',left:'50%',top:'50%',width:mobile?w*.72:w*.29,height:h*.83,translate:`calc(-50% + ${runnerX}px) -50%`,scale:1+travel*.08,willChange:f<200?'translate, scale':'auto'}}><GlowMotion {...glowRunner} inComposition priority enabled={ambientRunner} active={f<200} onPlaybackBlocked={onRunnerBlocked}/></div>
   <div style={{position:'absolute',left:pad,top:mobile?'19%':'20%',fontSize:mobile?w*.27:w*.2,lineHeight:.78,letterSpacing:'-.085em',fontWeight:500,translate:`${range(f,45,160,0,-w*.7)}px 0`}}>Más</div>
   <AnalogType text="vida." frame={Math.min(f,160)} width={mobile?w*.65:w*.43} height={mobile?w*.29:w*.21} style={{position:'absolute',right:pad,top:mobile?'59%':'48%',translate:`${range(f,45,160,0,w*.7)}px 0`}}/>
   <p style={{position:'absolute',left:pad,bottom:mobile?125:95,fontSize:mobile?16:18,lineHeight:1.45,maxWidth:260,opacity:range(f,20,90,1,0)}}>Salud preventiva.<br/>Para vivir a tu ritmo.</p>
   {!mobile&&<p style={{position:'absolute',right:pad,top:'23%',width:190,fontFamily:'Georgia,serif',fontSize:22,lineHeight:1.2,opacity:range(f,20,100,1,0)}}>Para lo que disfrutas.<br/>Y lo que está por venir.</p>}
  </AbsoluteFill>
  <AbsoluteFill data-layer="product-scene" style={{background:'#f3f0e8',color:'#171b18',overflow:'hidden',translate:`0 ${motion.productY*h}px`,visibility:Math.abs(motion.productY)>=1?'hidden':'visible',willChange:Math.abs(motion.productY)<1?'translate':'auto'}}>
   <div data-layer="product" data-hover={hover.toFixed(3)} style={{position:'absolute',left:mobile?'50%':'58%',top:'48%',width:mobile?Math.min(w*.96,h*.48):Math.min(w*.53,h*.85),aspectRatio:'1',transform:`translate(-50%, calc(-50% + ${hover}px))`}}>{(still||f>=80)&&<Img src={staticFile("art/tasso-plus-glow-v1.webp")} loading="lazy" decoding="async" style={{width:'100%',height:'100%',objectFit:'contain',maskImage:'radial-gradient(ellipse closest-side, black 76%, transparent 100%)'}}/>}</div>
   <div style={{position:'absolute',zIndex:1,top:mobile?'15%':'17%',left:pad,fontSize:mobile?Math.min(w*.11,48):w*.073,lineHeight:.94,letterSpacing:'-.06em'}}>Un pequeño<br/><span style={{fontFamily:'Georgia,serif',fontStyle:'italic',fontWeight:400}}>gesto.</span></div>
   <div style={{position:'absolute',right:pad,bottom:mobile?135:110,width:mobile?w-48:250}}><p style={{fontSize:11,letterSpacing:'.13em',marginBottom:10}}>01 / RECOGIDA CON TASSO+</p><p style={{fontSize:mobile?18:22,lineHeight:1.3}}>Recogida de muestra en casa, análisis en laboratorio acreditado.</p></div>
  </AbsoluteFill>
  <AbsoluteFill data-layer="insight-scene" style={{background:'#e9a067',color:'#22271f',overflow:'hidden',translate:`0 ${motion.insightY*h}px`,visibility:Math.abs(motion.insightY)>=1?'hidden':'visible',willChange:Math.abs(motion.insightY)<1?'translate':'auto'}}>
   <div style={{position:'absolute',top:mobile?'19%':'16%',left:pad,fontSize:mobile?51:w*.072,letterSpacing:'-.065em',lineHeight:.98}}>Tus datos.<br/><span style={{fontFamily:'Georgia,serif',fontStyle:'italic'}}>Con contexto.</span></div>
   <div ref={track} data-layer="insight-track" data-overflow={overflow} style={{position:'absolute',left:pad,top:mobile?'46%':'47%',display:'flex',gap:pad,width:'max-content',translate:`${-range(f,590,635,0,overflow)}px 0`}}>
    <div style={{width:w-pad*2,display:'flex',alignItems:'center',gap:mobile?22:55}}><span style={{fontSize:mobile?Math.min(w*.37,155):w*.22,letterSpacing:'-.08em',lineHeight:.8}}>15</span><span style={{fontSize:mobile?22:35,maxWidth:240,lineHeight:1.05}}>biomarcadores.<br/>Cada<br/>90 días.</span></div>
    <div style={{width:w-pad*2,fontSize:mobile?25:42,lineHeight:1.12}}>Tus resultados, explicados.<br/><span style={{fontFamily:'Georgia,serif',fontStyle:'italic'}}>Tu evolución, en perspectiva.</span><p style={{fontSize:mobile?16:18,lineHeight:1.4,maxWidth:420,marginTop:25}}>Compara tus lecturas a lo largo del tiempo y observa cómo cambian tus biomarcadores.</p></div>
   </div>
  </AbsoluteFill>
  <AbsoluteFill data-layer="return-to-life" style={{background:'#0b1010',overflow:'hidden',translate:`0 ${motion.lifeY*h}px`,visibility:Math.abs(motion.lifeY)>=1?'hidden':'visible',willChange:Math.abs(motion.lifeY)<1?'translate':'auto'}}>
   {(still||f>=600)&&<Img src={staticFile("art/stretch.jpg")} loading="lazy" decoding="async" style={{position:'absolute',height:'100%',width:mobile?'100%':'60%',left:mobile?'0':'22%',objectFit:'cover',maskImage:'radial-gradient(ellipse,black 15%,transparent 74%)',scale:range(f,710,840,1.18,1)}}/>}
   <div style={{position:'absolute',left:pad,top:mobile?'27%':'26%',fontSize:mobile?w*.18:w*.115,letterSpacing:'-.07em',lineHeight:.97,translate:`0 ${range(f,735,800,60,0)}px`}}>Y volver<br/><span style={{fontFamily:'Georgia,serif',fontStyle:'italic'}}>a la vida.</span></div>
   <p style={{position:'absolute',right:pad,bottom:mobile?135:110,fontSize:mobile?18:23,lineHeight:1.3,maxWidth:mobile?230:310}}>Cuidarte también es hacer<br/>espacio para lo que disfrutas.</p>
  </AbsoluteFill>
 </AbsoluteFill>
}
