import type {Metadata} from 'next';
import './globals.css';
export const metadata:Metadata={title:'EVA — Más vida.',description:'15 biomarcadores cada 90 días. Recogida de muestra en casa, análisis en laboratorio acreditado. Entiende tus resultados y sigue tu evolución con EVA.'};
export default function Layout({children}:{children:React.ReactNode}){return <html lang="es"><body>{children}</body></html>}
