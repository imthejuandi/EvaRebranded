import {Composition} from 'remotion';
import {EvaFilm,DURATION} from '../components/story/EvaFilm';
import {SignalFilm} from '../components/story/SignalFilm';
import {SIGNAL_DURATION} from '../lib/analog-motion';
export const RemotionRoot=()=> <><Composition id="EvaLandscape" component={EvaFilm} durationInFrames={DURATION} fps={30} width={1440} height={900}/><Composition id="EvaPortrait" component={EvaFilm} durationInFrames={DURATION} fps={30} width={390} height={844}/><Composition id="SignalLandscape" component={SignalFilm} durationInFrames={SIGNAL_DURATION} fps={30} width={1440} height={900}/><Composition id="SignalPortrait" component={SignalFilm} durationInFrames={SIGNAL_DURATION} fps={30} width={390} height={844}/></>;
