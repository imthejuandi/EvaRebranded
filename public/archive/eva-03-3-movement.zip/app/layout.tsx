import type {Metadata} from 'next';
import './globals.css';
export const metadata:Metadata={title:'EVA — Más vida.',description:'Una nueva forma de vivir tu salud. Salud preventiva, a tu ritmo. Estudio de diseño 03.'};
export default function Layout({children}:{children:React.ReactNode}){return <html lang="es"><body>{children}</body></html>}
