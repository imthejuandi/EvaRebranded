# EVA 03.3 — bounded design review

## Goal
Create an image-led EVA experience in which preventive health feels like an exciting part of life. Use the SAVEE board's optical defocus, grain and amber/lilac light on human subjects, factual Tasso+ reference imagery, and real reversible scroll-driven transitions authored with Remotion. Preserve core EVA information and every earlier design iteration.

## Stop rule
One full draft, a review of actual rendered scenes, then at most two focused correction passes. Finish only when the gates below pass. A successful build alone cannot pass the visual gates. Record limitations honestly; subjective approval remains with the user.

## Gates
1. **Connected scenes:** inspect frames 0, 171, 225, 325, 400, 480, 560, 680, 755 and 810. The runner leaves to the right. Full-height scenes move upward together through product, information and final human artwork, with no circular reveals or opening wipes. Check transition midpoints 205, 510 and 758. Adjacent panels must stay joined and navigation must contrast against the background behind it.
2. **Art direction:** compare the actual runner and stretch assets with SAVEE 08 and 09. Require observable optical defocus, grain, amber/blue/lilac light and a recognizable human subject. A conventional photograph with a CSS blur cannot pass.
3. **Actual scroll control:** on the experience page, native scroll changes the rendered Remotion frame. Return to an earlier chapter and verify its frame, pose, asset and geometry. Hold scroll still for at least two seconds and verify the Remotion frame and scene positions do not change. The ambient running loop may advance independently, as requested in refinement 03.1; its pause control must freeze the gait. The final frame must remain 840 after leaving the pinned stage.
4. **Composed layouts:** review 1440×900 and 390×844. The portrait composition must reflow text and product sizing. No horizontal page overflow, covered headlines, illegible chapter controls, or broken product frames. Secondary results have an 80-frame stationary reading interval before the final upward transition.
5. **EVA clarity and recovery:** ordinary HTML and reduced-motion mode retain Tasso+, 15 markers every quarter, optional 165+ panel, biological age/score, €99 per quarter, cancellation and free upload. Earlier sites and source archives remain linked. Real CTA destinations point to EVA.

## Historical improvements from the original review (superseded where noted)
- Replaced conventional lifestyle imagery with two Higgsfield artworks generated with the actual SAVEE references.
- Replaced the previous independent loop with 60 product frames selected by the Remotion timeline.
- Fixed phone product/title overlap and the visible white image rectangle.
- Anchored the product zoom to the button rather than the image center.
- Extended the secondary results reading hold to frames 635–715.
- Delayed chapter chrome color change until the final mask reaches it.
- Fixed incomplete local extraction and verified all 60 product frames exist.

## Repeat the test
Use /system to seek exact frames, inspect landscape and portrait compositions, and compare source imagery. Use the landing page's chapter navigation and native scrolling to check the actual scroll driver. The footer's reduced-motion switch removes the pinned sequence. Run `npm run check:delivery` after the production build for asset, core-copy and export checks. Results are recorded in results.json; they are observations, not an automated taste score.

## Runner refinement 03.1
One refined still and one forward-running clip. Verify lean athletic styling and readable kit, preserve optical glow/grain, inspect gait and loop join, then test native playback with stable scroll frame, pause/resume, offscreen pause, reduced motion and desktop/phone composition. Save the treatment as Glow Motion and retain the accepted 03.0 source.

## 03.2: analog typography and fixed dot motion

See `/review/analog-signal.md` for the six acceptance gates and finite review loop. The new passage adds no autoplay; native scroll supplies Remotion frames. Motion-state checks cover all 361 frames, fixed centers, complete glyphs, bounded input and identical reverse traversal. Previous 03.1 observations remain at `/review/03-1-results.json`.

##03.3: six requested refinements

See `/review/refinement-03-3.md`. Gates: no hero flowers; monotonic rightward exit; fixed device center and no rectangular background; original scattered board animation with 624 fixed calculator lamps (twice the previous density, eight times the initial lit-dot count); light wordmark; new healthy-lifestyle image integrated. Preserve responsive spacing, static alternatives, prior source archives and the existing factual content.

## Solar Motion refinement

Retain the approved image. Generate one12-second living photograph; require natural forward steps, people entering/exiting, a fixed camera, attached glow that trails and decays, and no extra figures or distorted bodies. Inspect early/middle/late frames and playback. Check pause/resume, offscreen pause, mobile fit, and reduced-motion still. Stop after these gates pass; regenerate only if a visible defect fails a gate.

### Final walking edit decision

Two focused generations did not achieve a credible physical entrance with natural gaze simultaneously. Use the stronger already-walking segment, trimmed after the dissolve. The explicit final gate is natural forward movement on the path, varied gaze, trailing glow, physical rightward exit, one play and manual replay. Do not claim a physical full-frame entrance. Keep the rejected takes in local history and stop the generation loop.
