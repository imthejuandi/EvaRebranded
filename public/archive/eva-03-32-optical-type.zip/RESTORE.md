# EVA 03.32

Apply these files over 03.31 to recover the natural Arial headline before the Impeccable-led composition refinement. Saved source: 7fd62380a363d5a64bb98b0fbe054a0f07601ef1. This revision was not publicly deployed.
