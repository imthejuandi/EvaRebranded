# Hero typography — 03.32

The latest clarification asks for balanced overall visual weight and the natural proportions of Conoce tu. It replaces the earlier literal width-and-height match.

HeroIntro keeps Arial at weight 400 and -0.035em tracking, using a font size equal to 24% of the analog frame width. SVG renders the actual typeface without textLength, lengthAdjust, or nonuniform scaling. The frame still scales uniformly for the poster and reduced-motion view. No canvas measurement, effect, or state is required for this static text.

The solid phrase is optically balanced against the taller, perforated serif lettering of salud. Their visible height is deliberately different; neither phrase is condensed or stretched to fit the other. The introduction retains its upper-left position and the dotted word remains lower-right.

The runner-head clearance and consistent static/animated framing from 03.31 remain. The 200 × 44px CTA, text exits, runner footage and analog effect are unchanged. The exact-dimension experiment is archived as an update over 03.30.
