'use client';

import type {CSSProperties} from 'react';

/** Balance solid lettering against the analog word without distorting the typeface. */
export function HeroIntro({width,height,style}:{width:number;height:number;style?:CSSProperties}){
 const fontSize=width*.24;
 return <span data-hero-intro aria-hidden="true" style={{display:'block',width,height,...style}}>
  <svg viewBox={`0 0 ${width} ${height}`} width="100%" height="100%" style={{display:'block',overflow:'visible'}}>
   <text x="0" y={height*.18+fontSize*.73} fill="currentColor" fontFamily="Arial, Helvetica, sans-serif" fontWeight="400" fontSize={fontSize} letterSpacing="-.035em">Conoce tu</text>
  </svg>
 </span>;
}
