import assert from 'node:assert/strict';
import {bodySignalState,BODY_SIGNAL_DURATION,BODY_RESOLVE_END,bodySignalStops} from '../lib/body-signal.ts';
import {signalState,signalStops,SIGNAL_DURATION} from '../lib/analog-motion.ts';
const coords=state=>state.points.map(({x,y})=>({x,y}));
const positions=coords(signalState(0)),frames=[];
let maxChange=0;
for(let f=0;f<BODY_SIGNAL_DURATION;f++){
 const state=bodySignalState(f);assert.deepEqual(coords(state),positions,'Lamps must retain their registered grid positions');
 assert(state.points.every(p=>Number.isFinite(p.r)&&p.r>=0&&p.r<.35),'All radii must be finite and bounded');
 if(f>0&&f<BODY_RESOLVE_END){const previous=bodySignalState(f-1);maxChange=Math.max(maxChange,...state.points.map((p,i)=>Math.abs(p.r-previous.points[i].r)))}
 frames.push(JSON.stringify(state));
}
assert(maxChange<.025,'Organic light must change continuously without a flash');
for(const frame of [0,60,120,165]){
 const p=bodySignalState(frame).points;
 assert(p.filter(p=>p.r>.2).length>100,'The reference needs merged luminous islands, not isolated sparkles');
 assert(p.filter(p=>p.r<.08).length>50,'The field must retain open dark channels and pinpricks');
 let close=0,far=0,nClose=0,nFar=0;
 for(let i=0;i<p.length;i++)for(let j=i+1;j<p.length;j++){
  const distance=Math.hypot(p[i].x-p[j].x,p[i].y-p[j].y),difference=Math.abs(p[i].r-p[j].r);
  if(distance<.4){close+=difference;nClose++}else if(distance>4){far+=difference;nFar++}
 }
 assert(close/nClose<far/nFar*.8,'Adjacent lamps must flow coherently instead of twinkling randomly');
}
for(let f=0;f<BODY_RESOLVE_END;f++)assert(bodySignalState(f).points.filter(p=>p.y<0).every(p=>p.r===0),'Accent sites must stay dark before the data sequence');
assert.notEqual(frames[0],frames[120],'The opening light field must move');
for(let f=0;f<SIGNAL_DURATION;f++)assert.deepEqual(bodySignalState(f+BODY_RESOLVE_END).points,signalState(f).points,'The resolved display must exactly preserve the accepted dot sequence');
assert.deepEqual(bodySignalStops,[0,...signalStops.map(f=>f+BODY_RESOLVE_END)]);
for(let f=BODY_SIGNAL_DURATION-1;f>=0;f--)assert.equal(JSON.stringify(bodySignalState(f)),frames[f],'Backward scroll must reconstruct the same image');
assert.deepEqual(bodySignalState(-10),bodySignalState(0));assert.deepEqual(bodySignalState(10000),bodySignalState(BODY_SIGNAL_DURATION-1));
console.log(`Body Signal passed: ${BODY_SIGNAL_DURATION} reversible frames; coherent luminous islands and open channels; bounded continuous radii; exact original 361-frame calculator sequence and chapter stops.`);
