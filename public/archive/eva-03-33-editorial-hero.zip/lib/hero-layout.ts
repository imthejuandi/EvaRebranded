/** A composed headline and protected image area, shared by the film's first frame. */
export function heroLayout(width:number,height:number){
 const mobile=width<=700;
 const introSize=mobile?Math.max(44,Math.min(width*.16,84)):Math.max(56,Math.min(width*.083,144));
 const introTop=mobile?Math.max(96,height*.135):Math.max(128,Math.min(height*.235,240));
 const introHeight=introSize*1.08;
 const saludWidth=mobile?width*.6:Math.max(220,Math.min(width*.29,520));
 const saludHeight=saludWidth*.4;
 const saludTop=mobile?Math.min(height*.55,height-256-saludHeight):height*.51;
 const runnerHeight=height*(mobile?.72:.82);
 return {
  introSize,introTop,introHeight,introWidth:introSize*4.6,
  saludWidth,saludHeight,saludTop,
  supportTop:introTop+introHeight+32,
  runnerHeight,runnerWidth:width*(mobile?.9:.31),
  runnerTop:mobile?Math.max(height*.16,introTop+introHeight+24-runnerHeight*.12):height*.07,
 };
}
