# Hero composition — 03.33

The user requested Impeccable to guide the whole hero composition, superseding the earlier restriction. The accepted objective is equal perceived importance with natural glyph proportions, not equal bounding boxes.

## Design decisions

- Use Hanken Grotesk regular for Conoce tu, paired with the existing serif analog effect. Selection reference: https://fonts.google.com/specimen/Hanken+Grotesk . Locally served regular and semibold files total about 57 KB, with the OFL included. Preload only the regular face.
- Keep a clear diagonal headline: introduction high-left and a smaller analog salud lower-right. Retain the runner in the center, with her head protected from the title.
- Group the supporting sentence 32px below the introduction and the compact CTA 20px below the two-line sentence. They share the existing page gutter. Remove the detached upper-right sentence.
- Recompose phones: the runner fills more of the center, the headline remains clear above her head, and the CTA follows salud after 24px, aligned to its right edge. Short screens move the entire lower group upward.
- Keep the 200 × 44px action and approved text. Its primary invitation remains semibold, with lighter kit detail and price. Navigation is secondary at the foot of the scene.
- Keep the original runner footage, glow, analog cells, rightward runner exit and opposing text exits. No extra animation loop or JavaScript font measurement is introduced.

## Bounded review criteria

Review desktop, typical phone and short phone. Stop once the text is undistorted, the subject’s face is clear, the action is grouped and readable, no horizontal overflow appears, and the reduced-motion layout preserves the composition. Check the transition into the next chapter for a hidden/inert outgoing CTA. Build and the existing delivery checks must pass.

Visual importance is an optical judgment; the phrases intentionally have different widths and letter heights. Viewport emulation cannot establish real-device performance.

Previous source revisions remain linked in the archive, including 03.32 before this composition change.
