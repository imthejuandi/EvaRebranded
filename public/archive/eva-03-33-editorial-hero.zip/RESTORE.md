# EVA 03.33

Apply these files over 03.32 to recover the first Impeccable-led hero composition, before centering the runner and lowering the action. Saved source: f12c64990443d7ac47b461c5a83b039932f67c69.

History downloads are independent sibling files, not embedded recursively in this update. Keep the public/archive folder when restoring. The 03.32 archive remains separately available at /archive/eva-03-32-optical-type.zip in the current study.
