# Frost / Analog Ink — 03.21

The existing navigation destinations are retained. Desktop links sit in a restrained translucent surface; at 900px and below, Explorar opens a warm frosted panel with a fine light edge. The backdrop blur is fixed at 24px; only the panel opacity and an eight-pixel entrance movement animate. A solid paper fallback is provided when backdrop filtering is unavailable or reduced transparency is requested.

## Letter behavior

`DotMorphLabel` samples the displayed typeface into a cached grid. Each source fragment resolves into a round dot at the same position, with a staggered left-to-right scan. It never changes the word's layout or swaps font families. Small coverage differences vary dot sizes. The effect takes 420ms forward and 320ms back; changing direction resumes from the current progress. Rendering stops at each endpoint. Only interaction starts animation; there is no ongoing shimmer or idle particle loop.

The original HTML text retains the accessible name. The canvas is decorative. Keyboard focus uses the same dot treatment and keeps a separate focus outline. Pointer selection does not intercept or delay the link. The open Explorar trigger stays dotted until it closes. Reduced motion preserves solid letters; forced-colors mode uses native text. Enlarged labels can wrap and retain native lettering when multiple lines are needed.

## Dropdown behavior

The installed Base UI Popover primitive provides dismissal, focus return, and portal positioning. Native anchors preserve normal browser behavior. Escape and outside interaction close the panel. One tap activates a destination on touch screens. The panel scrolls internally if its content exceeds the available height. Resizing to desktop closes the small-screen popup.

## Review

A bounded local Chrome check covers partial and complete morphs, mid-animation reversal, stable link geometry, idle rendering, 320px and 390px containment, keyboard focus and Escape, outside dismissal, one-tap links, reduced motion, and enlarged text. Screenshots and the final browser record are kept in the project workspace. This does not claim a physical-phone FPS measurement.

## Recovery

The approved still and previous navigation are retained in `/archive/eva-03-20-solar-still.zip`. Restore over 03.19 using its included rename/deletion instructions. All earlier downloadable archives remain available. No business content, claims, links, or existing artwork were changed for this navigation update.
