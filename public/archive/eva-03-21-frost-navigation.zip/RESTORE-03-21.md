# EVA 03.21

Apply this overlay over restored 03.20. The rounded frosted menu and its original type sizes are preserved.
Source: b2bc035df68f5daec28d4a6cce0b74ef99967889
All earlier archives remain separate downloads.
