# Restore EVA 03.30

Apply over 03.29 (f20ba40cc53eb8f831fb060a619ad9e452c0de0c) to restore source c43c3c714d4f3f89ed5dfae4efea6f7bdf9894c0. No deletions. Retain the existing public/archive files; they are excluded from this incremental archive.

This version preserves the smaller native Conoce tu, the compact kit CTA and the previous still-image framing.
