# EVA 03.22

Apply over restored 03.21. Preserves the 300px square menu, serif lettering, heading and language row.
Source: d97fe7bed859511fb2937c201abcba97d99d8244
Earlier downloadable archives remain separate.
