import {useId} from 'react';
import {AbsoluteFill,useCurrentFrame,useVideoConfig} from 'remotion';
import {bodySignalState,BODY_RESOLVE_END} from '@/lib/body-signal';
import {signalLabels,signalState} from '@/lib/analog-motion';
import {HALFTONE_VIEWBOX} from '@/lib/halftone-motion';
const descriptions=['Una mirada a lo que pasa dentro de ti.','Vuelve a conocerte. Observa cómo cambias.','Los datos son el principio. Tú decides cómo seguir.'];
const circle=(x:number,y:number,r:number)=>`M${x-r},${y}a${r},${r} 0 1,0 ${r*2},0a${r},${r} 0 1,0 ${-r*2},0`;
export function BodySignalFilm(){
 const frame=useCurrentFrame(),{width,height}=useVideoConfig(),mobile=width<700,pad=mobile?24:48;
 const state=bodySignalState(frame),board=signalState(Math.max(0,frame-BODY_RESOLVE_END));
 const id=useId().replace(/:/g,''),introFont=mobile?Math.min(width*.109,height*.059):width*.047,titleHeight=introFont*3.18;
 const fieldHeight=mobile?Math.min(height*.33,height-216-height*.34):height*.73;
 
 const titleTravel=Math.max(0,Math.min(1,(frame-215)/55));
 const path=state.points.filter(p=>p.r>0).map(p=>circle(p.x,p.y,p.r)).join('');
 return <AbsoluteFill data-body-signal-frame={frame} data-body-signal-phase={state.phase} data-body-resolve={state.resolve.toFixed(3)} style={{background:'#0b1010',color:'#f3f0e8',fontFamily:'Arial,Helvetica,sans-serif',overflow:'hidden'}}>
  <div style={{position:'absolute',top:mobile?36:48,left:pad,right:pad,display:'flex',justifyContent:'space-between',gap:20,borderTop:'1px solid #f3f0e838',paddingTop:17,fontSize:mobile?11:12,letterSpacing:'.1em'}}><span>UNA SEÑAL PARA CONOCERTE</span><span>0{state.chapter+1} / 04</span></div>
  <div style={{position:'absolute',left:pad,top:mobile?'15%':'26%',width:mobile?width-pad*2:width*.43,height:titleHeight,overflow:'hidden'}}>
   <div style={{position:'absolute',inset:0,translate:`0 ${-titleTravel*titleHeight}px`,fontSize:introFont,letterSpacing:'-.055em',lineHeight:1.03}}>Interpretamos<br/>las señales<br/><span style={{fontFamily:'Georgia,serif',fontStyle:'italic'}}>de tu cuerpo.</span></div>
   <div style={{position:'absolute',inset:0,translate:`0 ${(1-titleTravel)*titleHeight}px`,fontSize:mobile?Math.min(width*.117,height*.065):width*.057,letterSpacing:'-.055em',lineHeight:1.03}}>De los datos.<br/><span style={{fontFamily:'Georgia,serif',fontStyle:'italic'}}>A tu vida.</span></div>
  </div>
  <svg data-body-field="true" viewBox={HALFTONE_VIEWBOX} style={{position:'absolute',width:mobile?width*.91:width*.54,height:fieldHeight,left:mobile?'4.5%':'45%',top:mobile?'34%':'15%',overflow:'visible'}} aria-hidden="true">
   <defs><filter id={id+'-halo'} x="-25%" y="-25%" width="150%" height="150%"><feGaussianBlur stdDeviation=".16"/></filter><filter id={id+'-optical'} x="-25%" y="-25%" width="150%" height="150%"><feGaussianBlur stdDeviation={.025*state.glow}/></filter></defs>
   <g>
    {state.glow>0&&<path d={path} fill="#f3e4d5" filter={`url(#${id}-halo)`} opacity={state.glow*.8}/>}
    {state.resolve===1&&<path d={state.points.map(p=>circle(p.x,p.y,.013)).join('')} fill="#f3f0e8" opacity=".14"/>}
    <path data-body-lamps="true" d={path} fill="#f3f0e8" filter={state.glow>0?`url(#${id}-optical)`:undefined}/>
   </g>
  </svg>
  <div style={{position:'absolute',left:pad,top:mobile?undefined:'64%',bottom:mobile?106:undefined,maxWidth:mobile?width-48:310}}>
   <p style={{fontSize:mobile?23:28,letterSpacing:'-.03em',marginBottom:13}}>{state.phase==='data'?signalLabels[board.chapter]:'Cada señal cuenta.'}</p>
   <p style={{fontSize:16,lineHeight:1.5,maxWidth:300,color:'#bec4bb'}}>{state.phase==='data'?descriptions[board.chapter]:'De tus biomarcadores a una lectura de ti.'}</p>
  </div>
 </AbsoluteFill>;
}
