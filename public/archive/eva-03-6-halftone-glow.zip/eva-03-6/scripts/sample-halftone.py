"""Build small, portable glyph coverage masks; no runtime font dependency.
Source: system Arial Rounded MT Bold, for EVA's rounded instrument numerals.
Only geometric coverage is shipped, not the font file.
"""
from PIL import Image, ImageDraw, ImageFont
from pathlib import Path
import json
cols, rows, sample = 58, 42, 12
font = ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial Rounded Bold.ttf', 800)
masks = []
for word in ['15', '90', 'TÚ']:
    box = font.getbbox(word)
    glyph = Image.new('L', (box[2]-box[0], box[3]-box[1]))
    ImageDraw.Draw(glyph).text((-box[0],-box[1]), word, font=font, fill=255)
    factor = min((cols-4)*sample/glyph.width,(rows-4)*sample/glyph.height)
    glyph = glyph.resize((round(glyph.width*factor),round(glyph.height*factor)),Image.Resampling.LANCZOS)
    mask = Image.new('L',(cols*sample,rows*sample))
    mask.paste(glyph,((mask.width-glyph.width)//2,(mask.height-glyph.height)//2))
    coverage = list(mask.resize((cols,rows),Image.Resampling.BOX).getdata())
    masks.append(coverage)
Path('lib/halftone-masks.json').write_text(json.dumps(masks,separators=(',',':'))+'\n')
print('Sampled three rounded silhouettes onto',cols*rows,'fixed sites')
