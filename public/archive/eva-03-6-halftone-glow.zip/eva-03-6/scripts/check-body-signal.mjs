import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {readFileSync} from 'node:fs';
import {bodySignalState,BODY_SIGNAL_DURATION,BODY_RESOLVE_END,bodySignalStops} from '../lib/body-signal.ts';
import {halftoneState,HALFTONE_COLS,HALFTONE_ROWS,HALFTONE_PITCH} from '../lib/halftone-motion.ts';
import {signalStops,SIGNAL_DURATION} from '../lib/analog-motion.ts';
import {productHover} from '../lib/product-motion.ts';
const coords=s=>s.points.map(({x,y})=>({x,y}));
const positions=coords(halftoneState(0)),frames=[];
const hash=s=>createHash('sha256').update(JSON.stringify(s)).digest('hex');
let maxChange=0,previous;
for(let f=0;f<BODY_SIGNAL_DURATION;f++){
 const state=bodySignalState(f);
 assert.deepEqual(coords(state),positions,'The field and numbers must occupy the same registered screen');
 assert.equal(state.points.length,HALFTONE_COLS*HALFTONE_ROWS);
 assert(state.points.every(p=>Number.isFinite(p.r)&&p.r>=0&&p.r<.14));
 if(previous&&f<BODY_RESOLVE_END)maxChange=Math.max(maxChange,...state.points.map((p,i)=>Math.abs(p.r-previous.points[i].r)));
 previous=state;frames.push(hash(state));
}
assert(maxChange<.015,'Light must resolve smoothly without a flash');
for(const frame of [0,60,120,165]){
 const p=bodySignalState(frame).points;
 assert(p.filter(p=>p.r>.1).length>100,'Keep luminous islands');
 assert(p.filter(p=>p.r<.04).length>100,'Keep open dark channels');
 assert(p.filter(p=>p.x===0&&p.r>.025).length>5,'Opening must reach the left edge of the display');
 assert(p.filter(p=>p.x>11.3&&p.r>.025).length>5,'Opening must reach the right edge of the display');
}
for(const f of signalStops){
 const active=halftoneState(f).points.filter(p=>p.r>0);
 assert(active.length>300,'Each numeral must have a substantial readable silhouette');
 assert(new Set(active.map(p=>p.r.toFixed(3))).size>30,'Halftone must contain many visibly distinct dot sizes');
 assert(Math.max(...active.map(p=>p.r))-Math.min(...active.map(p=>p.r))>.035,'Dot-size variation must be visible');
 assert(active.every(p=>p.r*2<HALFTONE_PITCH*.87),'Retain visible gaps between the largest dots');
}
assert.notEqual(frames[0],frames[120]);
for(let f=0;f<SIGNAL_DURATION;f++)assert.deepEqual(bodySignalState(f+BODY_RESOLVE_END).points,halftoneState(f).points);
assert.deepEqual(bodySignalStops,[0,...signalStops.map(f=>f+BODY_RESOLVE_END)]);
// Intermediate boards contain lamps from both endpoints, not a whole-word opacity fade.
const a=halftoneState(0).points,b=halftoneState(160).points,mid=halftoneState(95).points;
const changing=a.map((p,i)=>i).filter(i=>a[i].r!==b[i].r);
assert(changing.some(i=>mid[i].r===a[i].r)&&changing.some(i=>mid[i].r===b[i].r));
assert(changing.every(i=>mid[i].r===a[i].r||mid[i].r===b[i].r));
for(let f=BODY_SIGNAL_DURATION-1;f>=0;f--)assert.equal(hash(bodySignalState(f)),frames[f],'Backward scroll reconstructs the same frame');
for(let f=0;f<841;f++){
 assert(Math.abs(productHover(f))<=8);
 assert(Math.abs(productHover(f+1)-productHover(f))<.34,'Hover must remain gentle');
}
const film=readFileSync('components/story/BodySignalFilm.tsx','utf8');
assert(!film.includes('scaleX')&&!film.includes('scaleY'),'Do not compress the opening screen');
const product=readFileSync('components/story/EvaFilm.tsx','utf8');
assert(!product.includes('rotate:')&&!product.includes('data-turn'),'Product holds its upright orientation');
console.log(`Body Signal passed: ${BODY_SIGNAL_DURATION} reversible frames; fixed full-size screen; rounded halftone with visible gaps and individual lamp switching; gentle eight-pixel product hover.`);
