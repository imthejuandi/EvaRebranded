import {halftoneState} from './halftone-motion.ts';
import {signalStops,signalLabels,SIGNAL_DURATION} from './analog-motion.ts';

export const BODY_RESOLVE_START=165;
export const BODY_RESOLVE_END=270;
export const BODY_SIGNAL_DURATION=BODY_RESOLVE_END+SIGNAL_DURATION;
export const bodySignalStops=[0,...signalStops.map(f=>f+BODY_RESOLVE_END)];
export const bodySignalLabels=['Tu cuerpo',...signalLabels];
const clamp=(n:number)=>Math.max(0,Math.min(1,n));
const smooth=(n:number)=>{const t=clamp(n);return t*t*(3-2*t)};
const mix=(a:number,b:number,t:number)=>a+(b-a)*t;
const seed=(x:number,y:number)=>{const v=Math.sin(x*127.1+y*311.7+47.23)*43758.5453;return v-Math.floor(v)};
function noise(x:number,y:number){const ix=Math.floor(x),iy=Math.floor(y),u=smooth(x-ix),v=smooth(y-iy);return mix(mix(seed(ix,iy),seed(ix+1,iy),u),mix(seed(ix,iy+1),seed(ix+1,iy+1),u),v)}
const opening=halftoneState(0);

/** A continuous light field, then the rounded halftone display, with the accepted lamp-switching rhythm. No clocks or random state. */
export function bodySignalState(frame:number){
 const f=Math.max(0,Math.min(BODY_SIGNAL_DURATION-1,frame));
 const resolve=smooth((f-BODY_RESOLVE_START)/(BODY_RESOLVE_END-BODY_RESOLVE_START));
 if(f>=BODY_RESOLVE_END){const board=halftoneState(f-BODY_RESOLVE_END);return {frame:f,resolve:1,glow:0,chapter:board.chapter+1,phase:'data' as const,points:board.points};}
 const time=f/30;
 const points=opening.points.map(p=>{
  const x=p.x*.72+Math.sin(p.y*.48+time*.33)*.38;
  const y=p.y*.76+Math.cos(p.x*.41-time*.26)*.34;
  const field=noise(x+time*.32,y-time*.27)*.7+noise(x*2.1-time*.18,y*2.1+time*.14)*.3;
  const illumination=smooth((field-.34)/.3);
  // Above half-pitch, adjacent lamps merge into soft islands. Off sites stay as pinpricks.
  const organic=.009+.128*illumination;
  const local=smooth((resolve-.12*noise(p.x*.5,p.y*.5))/.88);
  return {...p,r:mix(organic,p.r,local)};
 });
 return {frame:f,resolve,glow:1-resolve,chapter:0,phase:f<BODY_RESOLVE_START?'body' as const:'interpret' as const,points};
}
