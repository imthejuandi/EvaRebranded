import masks from './halftone-masks.json' with {type:'json'};
export const HALFTONE_COLS=58,HALFTONE_ROWS=42,HALFTONE_PITCH=.2;
export const HALFTONE_VIEWBOX='-.22 -.22 11.84 8.64';
const clamp=(n:number)=>Math.max(0,Math.min(1,n));
const sites=Array.from({length:HALFTONE_COLS*HALFTONE_ROWS},(_,i)=>({x:(i%HALFTONE_COLS)*HALFTONE_PITCH,y:Math.floor(i/HALFTONE_COLS)*HALFTONE_PITCH}));
const targets=masks.map(mask=>sites.map((p,i)=>{
 const coverage=mask[i]/255;
 // Edge coverage shapes the type; a broad optical falloff modulates dot area inside each stroke.
 const light=.67+.33*(.5+.5*Math.cos(p.x*.37+p.y*.28-.8));
 return coverage<.025?0:(.022+.064*Math.sqrt(coverage))*light;
}));
export function halftoneState(frame:number){
 const f=Math.max(0,Math.min(360,frame));
 const phase=f<160?clamp((f-55)/80):1+clamp((f-215)/80);
 const from=Math.min(1,Math.floor(phase)),to=Math.min(2,from+1);
 const step=Math.floor((phase-from)*8)/8;
 const chapter=phase<.5?0:phase<1.5?1:2;
 const points=sites.map((p,i)=>{
  // Keep the accepted eight-step, individual-lamp board switching, now with halftone targets.
  const switched=step>=1||step>((i*7)%17)/16;
  return {...p,r:targets[switched?to:from][i]};
 });
 return {chapter,points};
}
