# Restore this EVA version

The original files are preserved losslessly. Download eva-03-12-time-and-life.zip alongside this archive. Files tagged base in RESTORE-MANIFEST.json come from that archive; files tagged patch come from this one. The manifest includes the SHA-256 of every original file. Extract only the listed original files for an exact reconstruction.
