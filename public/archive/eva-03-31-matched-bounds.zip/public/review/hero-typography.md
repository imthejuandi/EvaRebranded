# Hero typography — 03.31

The user explicitly requested equal overall width and equal letter height for Conoce tu and salud. The two phrases now share the same responsive frame: 36vw capped at 640px on desktop, 62vw on mobile, and a 5:2 aspect ratio.

HeroIntro uses browser text metrics to fit Conoce tu to the visible ink width and height of the analog salud word, retaining regular-weight sans-serif letters in a condensed presentation. It uses the same Times New Roman / Georgia measurement, width fitting and step allowance as AnalogType. The sans-serif ascent and descent determine its baseline and scale; SVG textLength fits the complete phrase horizontally. Metrics are recalculated only when dimensions change, not on scroll. The original analog component is unchanged.

The introduction starts at max(94px, 10% stage height) on desktop and max(86px, 10% stage height) on mobile, retaining the left gutter. Salud keeps its lower-right position. On mobile, the runner’s upper edge accounts for the introduction height and the source image’s head location, leaving clear space for the head. Existing leftward text exit and rightward runner exit remain.

The poster and reduced-motion version share the same runner width, height, crop, position and feathered mask as the initial animated composition. This removes the older oversized crop that could place the head behind the text or header. The reduced-motion hero clips its image within its own section.

The compact kit CTA remains 200 × 44px at the default root size. The previous 03.30 source is recoverable in the history archive.
