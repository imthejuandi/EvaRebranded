# EVA 03.31

Apply these files over 03.30 to recover the exact-width and exact-height headline experiment. This version was saved but not published. The user subsequently preferred natural proportions and balanced visual weight.

Source commit: e7dcf132eb982364106d1211df066980b009e2db
