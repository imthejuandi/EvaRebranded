'use client';

import {useEffect,useState,type CSSProperties} from 'react';

/** Fit the complete introduction to the same visible bounds as the analog word. */
export function HeroIntro({width,height,style}:{width:number;height:number;style?:CSSProperties}){
 const [type,setType]=useState({fontSize:height,y:height*.86,length:width*.94});
 useEffect(()=>{
  const ctx=document.createElement('canvas').getContext('2d');if(!ctx)return;
  const step=Math.max(2.6,width/104);
  let size=height*1.18;ctx.font=`${size}px "Times New Roman", Georgia, serif`;
  size*=Math.min(1,(width-step*2)/ctx.measureText('salud.').width);
  ctx.font=`${size}px "Times New Roman", Georgia, serif`;
  const target=ctx.measureText('salud.'),inkHeight=target.actualBoundingBoxAscent+target.actualBoundingBoxDescent;
  const inkWidth=target.actualBoundingBoxLeft+target.actualBoundingBoxRight;
  ctx.font='100px Arial, Helvetica, sans-serif';
  const intro=ctx.measureText('Conoce tu'),scale=inkHeight/(intro.actualBoundingBoxAscent+intro.actualBoundingBoxDescent);
  setType({fontSize:100*scale,y:(height-inkHeight)/2+intro.actualBoundingBoxAscent*scale,length:inkWidth*intro.width/(intro.actualBoundingBoxLeft+intro.actualBoundingBoxRight)});
 },[width,height]);
 return <span data-hero-intro aria-hidden="true" style={{display:'block',width,height,...style}}>
  <svg viewBox={`0 0 ${width} ${height}`} width="100%" height="100%" style={{display:'block',overflow:'visible'}}>
   <text x="50%" y={type.y} textAnchor="middle" textLength={type.length} lengthAdjust="spacingAndGlyphs" fill="currentColor" fontFamily="Arial, Helvetica, sans-serif" fontWeight="400" fontSize={type.fontSize} letterSpacing="0">Conoce tu</text>
  </svg>
 </span>;
}
