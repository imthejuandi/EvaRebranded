'use client';
import {useEffect,useState} from 'react';
import {Popover} from '@base-ui/react/popover';
import {businessLinks} from '@/lib/landing-content';
import {DotMorphLabel} from './DotMorphLabel';

const links=[['Cómo funciona',businessLinks.method],['Ciencia',businessLinks.science],['Precios',businessLinks.pricing],['Nosotros',businessLinks.about]];

export function BusinessNavigation(){
 const [open,setOpen]=useState(false);
 useEffect(()=>{
  const desktop=matchMedia('(min-width: 901px)');
  const close=()=>{if(desktop.matches)setOpen(false)};
  desktop.addEventListener('change',close);
  return()=>desktop.removeEventListener('change',close);
 },[]);
 return <>
  <nav className="business-nav frost-inline" aria-label="EVA Health">
   {links.map(([name,url])=><a key={url} href={url}><DotMorphLabel>{name}</DotMorphLabel></a>)}
  </nav>
  <div className="business-menu">
   <Popover.Root open={open} onOpenChange={setOpen}>
    <Popover.Trigger className="frost-trigger">
     <DotMorphLabel selected={open}>Menú</DotMorphLabel>
     <span className="frost-trigger-mark" aria-hidden="true"/>
    </Popover.Trigger>
    <Popover.Portal>
     <Popover.Positioner side="bottom" align="center" sideOffset={18} collisionPadding={16} className="frost-positioner">
      <Popover.Popup className="frost-menu" aria-label="Explorar EVA" initialFocus={type=>type==='keyboard'}>
       <nav aria-label="Explorar EVA">
        {links.map(([name,url])=><a key={url} href={url}><DotMorphLabel>{name}</DotMorphLabel></a>)}
       </nav>
      </Popover.Popup>
     </Popover.Positioner>
    </Popover.Portal>
   </Popover.Root>
  </div>
 </>;
}
