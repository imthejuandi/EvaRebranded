import bpy,bmesh,math,time
from mathutils import Vector
t0=time.time();sc=bpy.context.scene
fixed=[]
for name in ['Satin white rounded external shell','Clear shallow rear shell perimeter','Thin external shell seam']:
 o=bpy.data.objects[name];bm=bmesh.new();bm.from_mesh(o.data)
 bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces));bm.to_mesh(o.data);o.data.update()
 fixed.append({'name':name,'positive_volume_m3':bm.calc_volume(signed=True)});bm.free()
# Keep matte white identifiable; deepen environment instead of tinting the whole device.
table=bpy.data.materials['Pale lilac stone tabletop'].node_tree.nodes.get('Principled BSDF')
table.inputs['Base Color'].default_value=(.040,.023,.073,1)
world=sc.world.node_tree.nodes.get('Background')
world.inputs['Color'].default_value=(.024,.015,.045,1);world.inputs['Strength'].default_value=.16
lights={
 'Coral morning key':((1,.38,.22),4.5,.065),
 'Cool violet soft fill':((.30,.23,.74),1.65,.065),
 'Neutral front soft reflection':((1,.91,.82),3.0,.075)}
for name,(color,power,radius) in lights.items():
 d=bpy.data.objects[name].data;d.color=color;d.energy=power;d.shadow_soft_size=radius
sc.eevee.taa_render_samples=40
# Blender 5.2 compositor node group with gentle highlight halation.
ng=bpy.data.node_groups.new('Editorial coral optical halation','CompositorNodeTree')
ng.interface.new_socket(name='Image',in_out='OUTPUT',socket_type='NodeSocketColor')
rl=ng.nodes.new('CompositorNodeRLayers');out=ng.nodes.new('NodeGroupOutput');g=ng.nodes.new('CompositorNodeGlare')
glare_note=''
try:
 g.inputs['Type'].default_value='Fog Glow'
 g.inputs['Quality'].default_value='Medium'
 g.inputs['Threshold'].default_value=.65
 g.inputs['Strength'].default_value=.22
 g.inputs['Size'].default_value=.42
 ng.links.new(rl.outputs['Image'],g.inputs['Image']);ng.links.new(g.outputs['Image'],out.inputs['Image'])
except Exception as e:
 glare_note=str(e);ng.links.new(rl.outputs['Image'],out.inputs['Image'])
sc.compositing_node_group=ng
# Closed, then physically lift the single rigid lid upward and away; product remains seated.
lid=bpy.data.objects['BOX_LID_RIGID_LIFT'];lid.animation_data_clear()
for frame,loc,angle in [
 (1,(0,0,.037),0),
 (12,(0,.005,.047),-1),
 (44,(0,.105,.119),-7),
 (66,(0,.205,.145),-10),
 (120,(0,.205,.145),-10)]:
 lid.location=loc;lid.rotation_euler=(math.radians(angle),0,0)
 lid.keyframe_insert('location',frame=frame);lid.keyframe_insert('rotation_euler',frame=frame)
action=lid.animation_data.action;curves=[]
if hasattr(action,'fcurves'):curves.extend(action.fcurves)
for layer in getattr(action,'layers',[]):
 for strip in getattr(layer,'strips',[]):
  for bag in getattr(strip,'channelbags',[]):curves.extend(bag.fcurves)
for fc in curves:
 for kp in fc.keyframe_points:kp.interpolation='BEZIER';kp.handle_left_type='AUTO_CLAMPED';kp.handle_right_type='AUTO_CLAMPED'
sc.render.fps=24;sc.frame_start=1;sc.frame_end=120
sc.render.image_settings.media_type='IMAGE';sc.render.image_settings.file_format='PNG'
sc.render.resolution_percentage=100
def render(name):
 target=artifacts.file(name=name,media_type='image/png')
 sc.render.filepath=target.path;bpy.ops.render.render(write_still=True);target.publish()

sc.camera=bpy.data.objects['Delivery box three-quarter camera']
sc.render.resolution_x=720;sc.render.resolution_y=792
lid.scale=(1.04,1.04,1)
sc.frame_set(120)
result={'normal_corrections':fixed,'glare_note':glare_note,'keyed_channels':len(curves),'frames':120,'fps':24,'image_texture_count':sum(1 for m in bpy.data.materials if m.use_nodes for n in m.node_tree.nodes if n.type=='TEX_IMAGE'),'lid_clearance_scale':list(lid.scale)}

