from pathlib import Path
import json,struct,hashlib
folder=Path(__file__).resolve().parent
source=folder/'tasso-plus-unboxing-scene.glb'
target=folder/'tasso-plus-exterior-model.glb'
raw=source.read_bytes()
magic,version,total=struct.unpack_from('<4sII',raw,0)
assert magic==b'glTF' and version==2 and total==len(raw)
chunks=[];offset=12
while offset<len(raw):
 size,kind=struct.unpack_from('<II',raw,offset);offset+=8
 chunks.append((kind,raw[offset:offset+size]));offset+=size
doc=json.loads(next(data for kind,data in chunks if kind==0x4e4f534a))
original=doc['nodes']
root=next(i for i,node in enumerate(original) if node.get('name')=='TASSO_PLUS_RIGID_ASSEMBLY')
keep=set()
def visit(index):
 if index in keep:return
 keep.add(index)
 for child in original[index].get('children',[]):visit(child)
visit(root)
indices=sorted(keep);mapping={old:new for new,old in enumerate(indices)}
nodes=[original[i] for i in indices]
for node in nodes:
 if 'children' in node:node['children']=[mapping[i] for i in node['children']]
 node.pop('camera',None)
rootnode=nodes[mapping[root]]
if 'translation' in rootnode:rootnode['translation']=[0,0,0]
if 'matrix' in rootnode:
 for i in [12,13,14]:rootnode['matrix'][i]=0
mesh_ids=sorted({n['mesh'] for n in nodes if 'mesh' in n})
mesh_map={old:new for new,old in enumerate(mesh_ids)}
doc['meshes']=[doc['meshes'][i] for i in mesh_ids]
for node in nodes:
 if 'mesh' in node:node['mesh']=mesh_map[node['mesh']]
mat_ids=sorted({p['material'] for m in doc['meshes'] for p in m['primitives'] if 'material' in p})
mat_map={old:new for new,old in enumerate(mat_ids)}
doc['materials']=[doc['materials'][i] for i in mat_ids]
for mesh in doc['meshes']:
 for primitive in mesh['primitives']:
  if 'material' in primitive:primitive['material']=mat_map[primitive['material']]
doc['nodes']=nodes;doc['scenes']=[{'name':'Tasso+ exterior model only','nodes':[mapping[root]]}];doc['scene']=0
doc.pop('animations',None);doc.pop('cameras',None)
if 'extensions' in doc:doc['extensions'].pop('KHR_lights_punctual',None)
for k in ['extensionsUsed','extensionsRequired']:
 if k in doc:doc[k]=[x for x in doc[k] if x!='KHR_lights_punctual']
doc.setdefault('asset',{}).setdefault('extras',{})['reconstruction_note']='Approximate exterior model from official Tasso+ public reference imagery. Not manufacturing CAD. Original scene mesh data preserved.'
text=json.dumps(doc,separators=(',',':')).encode();text+=b' '*((-len(text))%4)
parts=[struct.pack('<II',len(text),0x4e4f534a)+text]
for kind,data in chunks:
 if kind!=0x4e4f534a:parts.append(struct.pack('<II',len(data),kind)+data)
body=b''.join(parts);output=struct.pack('<4sII',b'glTF',2,len(body)+12)+body
target.write_bytes(output)
summary={'source':source.name,'output':target.name,'bytes':len(output),'sha256':hashlib.sha256(output).hexdigest(),'nodes':[n.get('name') for n in nodes],'meshes':len(doc['meshes']),'materials':len(doc['materials']),'images':len(doc.get('images',[])),'method':'Selected the existing rigid product assembly graph from scene export, recentered origin and preserved original mesh buffers. No geometry generated or altered; unused accessor/buffer data may remain.'}
(folder/'model-only-export.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary))

