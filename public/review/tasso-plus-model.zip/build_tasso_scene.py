import bpy, math, time
from mathutils import Vector
t0=time.time()
sc=bpy.context.scene
sc.unit_settings.system='METRIC'
sc.unit_settings.scale_length=1.0
sc.render.engine='BLENDER_EEVEE'
sc.render.resolution_x=640
sc.render.resolution_y=704
sc.render.resolution_percentage=100
sc.render.image_settings.media_type='IMAGE'
sc.render.image_settings.file_format='PNG'
sc.render.image_settings.color_mode='RGBA'
sc.render.film_transparent=False
sc.render.fps=24
sc.frame_start=1
sc.frame_end=120
sc.eevee.taa_render_samples=24
sc.world=bpy.data.worlds.new('Studio soft violet ambient')
sc.world.use_nodes=True
sc.world.node_tree.nodes.get('Background').inputs['Color'].default_value=(.28,.25,.36,1)
sc.world.node_tree.nodes.get('Background').inputs['Strength'].default_value=.32

def collection(name):
 c=bpy.data.collections.new(name);sc.collection.children.link(c);return c
product=collection('TASSO_PLUS_EXTERNAL_MODEL')
pack=collection('WARM_WHITE_SAMPLE_KIT_BOX')
studio=collection('STUDIO_CAMERAS_AND_LIGHTS')

def move(obj,col):
 for c in list(obj.users_collection):c.objects.unlink(obj)
 col.objects.link(obj)
 return obj
def material(name,color,rough=.4,trans=0,metal=0):
 m=bpy.data.materials.new(name);m.use_nodes=True
 p=m.node_tree.nodes.get('Principled BSDF')
 p.inputs['Base Color'].default_value=(*color,1)
 p.inputs['Roughness'].default_value=rough
 p.inputs['Metallic'].default_value=metal
 p.inputs['Transmission Weight'].default_value=trans
 p.inputs['IOR'].default_value=1.46
 m.diffuse_color=(*color,1)
 return m
white=material('Tasso warm white satin polymer',(.82,.825,.81),.26)
clear=material('Tasso translucent rear perimeter',(.84,.87,.87),.22,.45)
red=material('Tasso coral red raised button',(.79,.067,.045),.3)
seam=material('Fine polymer assembly seam',(.55,.58,.57),.4)
redrim=material('Coral button inset edge',(.38,.016,.012),.38)
glass=material('Clear collection vial polymer',(.82,.89,.91),.16,.82)
paper=material('Box warm white uncoated cardboard',(.82,.775,.686),.8)
insertmat=material('Fitted warm ivory insert',(.62,.587,.516),.92)
tablemat=material('Pale lilac stone tabletop',(.385,.365,.42),.84)
label=material('Blank collection vial label',(.88,.87,.84),.68)

root=bpy.data.objects.new('TASSO_PLUS_RIGID_ASSEMBLY',None);product.objects.link(root)
root.location=(0,.017,.0115)
root['reconstruction']='Approximate external visual model, not manufacturing CAD'
root['nominal_shell_width_m']=.043
root['reference']='Official Tasso+ product photo and public in-use image; no medical internals'
# Smooth closed contour reconstructed from visible front silhouette.
control=[(0,.025),(.011,.0233),(.019,.016),(.0215,.004),(.0197,-.009),(.0136,-.020),(.0071,-.025),(-.0071,-.025),(-.0136,-.020),(-.0197,-.009),(-.0215,.004),(-.019,.016),(-.011,.0233)]
outline=[]
for i in range(len(control)):
 p0=Vector(control[(i-1)%len(control)]);p1=Vector(control[i]);p2=Vector(control[(i+1)%len(control)]);p3=Vector(control[(i+2)%len(control)])
 for j in range(8):
  t=j/8
  p=.5*((2*p1)+(-p0+p2)*t+(2*p0-5*p1+4*p2-p3)*t*t+(-p0+3*p1-3*p2+p3)*t*t*t)
  outline.append((p.x,p.y))
def contour_solid(name,levels,mat,col=product,parent=root):
 verts=[(x*s,y*s,z) for z,s in levels for x,y in outline]
 n=len(outline);faces=[]
 for k in range(len(levels)-1):
  for j in range(n):faces.append((k*n+j,k*n+(j+1)%n,(k+1)*n+(j+1)%n,(k+1)*n+j))
 faces.append(tuple(reversed(range(n))))
 faces.append(tuple((len(levels)-1)*n+j for j in range(n)))
 mesh=bpy.data.meshes.new(name+' geometry');mesh.from_pydata(verts,[],faces);mesh.update()
 obj=bpy.data.objects.new(name,mesh);col.objects.link(obj);obj.data.materials.append(mat)
 for p in obj.data.polygons:p.use_smooth=len(p.vertices)==4
 obj.parent=parent
 return obj
rear=contour_solid('Clear shallow rear shell perimeter',[(0,.92),(.0007,.985),(.0024,1),(.0031,.996)],clear)
body=contour_solid('Satin white rounded external shell',[(.0029,.994),(.004,1),(.0075,.995),(.0108,.962),(.013,.88),(.0136,.71)],white)
assemblyseam=contour_solid('Thin external shell seam',[(.0029,.998),(.00322,.998)],seam)
def cylinder(name,radius,depth,loc,mat,rotation=(0,0,0),bevel=.0004,col=product,parent=root):
 bpy.ops.mesh.primitive_cylinder_add(vertices=96,radius=radius,depth=depth,location=(0,0,0))
 o=move(bpy.context.object,col);o.name=name;o.location=loc;o.rotation_euler=rotation;o.parent=parent
 o.data.materials.append(mat)
 if bevel:
  b=o.modifiers.new('Soft molded edge','BEVEL');b.width=bevel;b.segments=4
 for p in o.data.polygons:p.use_smooth=len(p.vertices)==4
 return o
cylinder('Circular button perimeter shadow gap',.0154,.0007,(0,.0042,.01355),redrim,bevel=.0002)
button=cylinder('Raised coral red circular button UNPRESSED',.01515,.0028,(0,.0042,.0151),red,bevel=.0009)
# Two opposing shallow embossed curves; real geometry on the button, not a texture plane.
def curve_tube(name,points,radius,mat):
 cv=bpy.data.curves.new(name,'CURVE');cv.dimensions='3D';cv.resolution_u=16
 sp=cv.splines.new('BEZIER');sp.bezier_points.add(len(points)-1)
 for b,co in zip(sp.bezier_points,points):b.co=co;b.handle_left_type='AUTO';b.handle_right_type='AUTO'
 cv.bevel_depth=radius;cv.bevel_resolution=3
 o=bpy.data.objects.new(name,cv);product.objects.link(o);o.parent=root;o.data.materials.append(mat);return o
curve_tube('Button embossed upper curved mark',[(-.006,.003,.01652),(-.002,.0035,.01652),(.0005,.006,.01652),(.0005,.010,.01652)],.00014,red)
curve_tube('Button embossed lower curved mark',[(.006,.0054,.01652),(.002,.0049,.01652),(-.0005,.0024,.01652),(-.0005,-.0016,.01652)],.00014,red)
cylinder('White underside vial connector',.0044,.0065,(0,-.0267,.0065),white,(math.pi/2,0,0),.00065)
cylinder('Translucent vial collar',.00535,.004,(0,-.0311,.0065),clear,(math.pi/2,0,0),.00035)
# Hollow collection tube around Y axis, with rounded closed bottom.
profile=[(-.031,.00495),(-.034,.0048),(-.059,.0048),(-.062,.0044),(-.063,.0028),(-.0632,0),(-.0626,0),(-.0623,.0024),(-.0614,.0038),(-.0588,.00415),(-.034,.00415),(-.031,.0043)]
verts=[];faces=[];n=96
for y,r in profile:
 for j in range(n):
  a=2*math.pi*j/n;verts.append((r*math.cos(a),y,.0065+r*math.sin(a)))
for k in range(len(profile)-1):
 for j in range(n):faces.append((k*n+j,k*n+(j+1)%n,(k+1)*n+(j+1)%n,(k+1)*n+j))
for j in range(n):faces.append(((len(profile)-1)*n+j,(len(profile)-1)*n+(j+1)%n,(j+1)%n,j))
mesh=bpy.data.meshes.new('Hollow vial true wall geometry');mesh.from_pydata(verts,[],faces);mesh.update()
vial=bpy.data.objects.new('Attached empty clear collection vial',mesh);product.objects.link(vial);vial.parent=root;vial.data.materials.append(glass)
for p in mesh.polygons:p.use_smooth=True
# Blank label is a wrapped, thin shell, not a source image or device cutout.
verts=[];faces=[]
for y in [-.037,-.057]:
 for j in range(25):
  a=math.pi/2+(-.48+j/24*.96);verts.append((.00485*math.cos(a),y,.0065+.00485*math.sin(a)))
for j in range(24):faces.append((j,j+1,26+j,25+j))
mesh=bpy.data.meshes.new('Wrapped blank label geometry');mesh.from_pydata(verts,[],faces);mesh.update()
o=bpy.data.objects.new('Blank narrow vial label',mesh);product.objects.link(o);o.parent=root;o.data.materials.append(label)
sol=o.modifiers.new('Physical paper thickness','SOLIDIFY');sol.thickness=.000035

def cube(name,loc,dims,mat,col=pack,parent=None,bevel=.0008):
 bpy.ops.mesh.primitive_cube_add(size=1,location=loc);o=move(bpy.context.object,col);o.name=name;o.dimensions=dims
 bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
 o.parent=parent;o.data.materials.append(mat)
 if bevel:
  b=o.modifiers.new('Soft paper edge','BEVEL');b.width=bevel;b.segments=3
 return o
base=cube('Box solid base',(0,0,.0025),(.096,.124,.005),paper)
for name,loc,dims in [
 ('Box left wall',(-.0465,0,.018),(.003,.124,.031)),
 ('Box right wall',(.0465,0,.018),(.003,.124,.031)),
 ('Box back wall',(0,.0605,.018),(.09,.003,.031)),
 ('Box front wall',(0,-.0605,.018),(.09,.003,.031))]:cube(name,loc,dims,paper)
foam=cube('Fitted insert with actual device recess',(0,0,.009),(.089,.117,.010),insertmat,bevel=.001)
# Real Boolean recess following shell silhouette and collection tube channel.
cutter=contour_solid('TEMP shell recess cutter',[(.0105,1.09),(.04,1.09)],white,col=pack,parent=None)
cutter.location=(0,.017,0)
mod=foam.modifiers.new('Fitted shell cavity','BOOLEAN');mod.operation='DIFFERENCE';mod.object=cutter
bpy.context.view_layer.objects.active=foam
bpy.ops.object.modifier_apply(modifier=mod.name)
bpy.data.objects.remove(cutter,do_unlink=True)
cutter=cube('TEMP vial recess cutter',(0,-.03,.020),(.013,.043,.020),insertmat,bevel=.004)
bpy.context.view_layer.objects.active=cutter
bpy.ops.object.modifier_apply(modifier=cutter.modifiers[0].name)
mod=foam.modifiers.new('Fitted vial cavity','BOOLEAN');mod.operation='DIFFERENCE';mod.object=cutter
bpy.context.view_layer.objects.active=foam;bpy.ops.object.modifier_apply(modifier=mod.name)
bpy.data.objects.remove(cutter,do_unlink=True)
lid=bpy.data.objects.new('BOX_LID_RIGID_LIFT',None);pack.objects.link(lid)
cube('Lid top',(0,0,.004),(.1,.128,.004),paper,parent=lid)
for name,loc,dims in [
 ('Lid left rim',(-.0485,0,-.002),(.003,.128,.012)),
 ('Lid right rim',(.0485,0,-.002),(.003,.128,.012)),
 ('Lid back rim',(0,.0625,-.002),(.094,.003,.012)),
 ('Lid front rim',(0,-.0625,-.002),(.094,.003,.012))]:cube(name,loc,dims,paper,parent=lid)
lid.location=(0,0,.037)
cube('Lilac stone presentation surface',(0,0,-.006),(.7,.7,.012),tablemat,col=studio,bevel=.005)
def camera(name,loc,target,ortho=.205):
 d=bpy.data.cameras.new(name);o=bpy.data.objects.new(name,d);studio.objects.link(o)
 o.location=loc;o.rotation_euler=(Vector(target)-o.location).to_track_quat('-Z','Y').to_euler()
 d.type='ORTHO';d.ortho_scale=ortho;d.lens=60;d.clip_start=.001;d.clip_end=10;return o
cam=camera('Delivery box three-quarter camera',(.135,-.19,.245),(0,0,.026),.205);sc.camera=cam
camera('Neutral front product camera',(0,.017,.30),(0,.017,0),.115)
camera('Neutral three-quarter product camera',(.13,-.07,.20),(0,-.003,.016),.14)
def light(name,loc,target,color,power,radius):
 d=bpy.data.lights.new(name,'POINT');d.color=color;d.energy=power;d.shadow_soft_size=radius
 o=bpy.data.objects.new(name,d);studio.objects.link(o);o.location=loc;return o
light('Coral morning key',(-.11,-.09,.22),(0,0,0),(1,.55,.40),8,.075)
light('Cool violet soft fill',(.14,.045,.16),(0,0,0),(.57,.58,1),4,.095)
light('Neutral front soft reflection',(0,-.12,.28),(0,0,0),(1,.95,.85),6,.1)
# First blockout preview: open lid held behind device. Later animation will be authored after review.
lid.location=(0,.15,.08);lid.rotation_euler=(math.radians(-10),0,0)
sc.frame_set(1)
target=artifacts.file(name='tasso-box-blockout.png',media_type='image/png')
sc.render.filepath=target.path
bpy.ops.render.render(write_still=True)
target.publish()
result={'elapsed_seconds':time.time()-t0,'objects':len(bpy.data.objects),'product_objects':[{'name':o.name,'type':o.type,'dimensions_m':list(o.dimensions)} for o in product.objects],'cameras':[o.name for o in studio.objects if o.type=='CAMERA'],'render_engine':sc.render.engine,'render_size':[640,704],'product_reference_dimensions_are_approximate':True}

