"""Run with Blender5.2: blender -b tasso-plus-unboxing-scene.blend -P render_local.py -- reveal.mp4"""
import sys
from pathlib import Path
import bpy

output = sys.argv[sys.argv.index('--') + 1] if '--' in sys.argv else 'tasso-reveal.mp4'
scene = bpy.context.scene
scene.render.engine = 'CYCLES'
scene.cycles.device = 'CPU'
scene.cycles.samples = 8
scene.cycles.use_denoising = True
scene.cycles.max_bounces = 5
scene.cycles.diffuse_bounces = 2
scene.cycles.glossy_bounces = 2
scene.cycles.transmission_bounces = 4
scene.render.resolution_x = 540
scene.render.resolution_y = 594
scene.render.resolution_percentage = 100
scene.render.fps = 24
scene.frame_start = 13
scene.frame_end = 66
scene.render.image_settings.media_type = 'VIDEO'
scene.render.image_settings.file_format = 'FFMPEG'
scene.render.ffmpeg.format = 'MPEG4'
scene.render.ffmpeg.codec = 'H264'
scene.render.ffmpeg.constant_rate_factor = 'HIGH'
scene.render.ffmpeg.audio_codec = 'NONE'
scene.render.use_persistent_data = True
scene.render.filepath = str(Path(output).resolve())
bpy.ops.render.render(animation=True)
